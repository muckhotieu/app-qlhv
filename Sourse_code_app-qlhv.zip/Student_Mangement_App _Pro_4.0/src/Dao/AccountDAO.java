/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import model.Account;

public interface AccountDAO {
    public Account login(String userName, String passWord);
    public boolean register(Account account);
    public boolean  isUsernameExist(String username);
}
