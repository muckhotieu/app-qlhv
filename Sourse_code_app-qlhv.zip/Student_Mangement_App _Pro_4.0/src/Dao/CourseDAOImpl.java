package Dao;

import Bean.EnrollmentData;
import Model.Course;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author MUCKHOTAU
 */
public class CourseDAOImpl implements CourseDAO {

    @Override
    public List<Course> getList(boolean isDeleted) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Course> list = new ArrayList<>();
        try {
            conn = DBConnect.getConnection();
            conn.setAutoCommit(false); // Bắt đầu transaction
            String sql = isDeleted ? "SELECT * FROM course WHERE status = false" : "SELECT * FROM course WHERE status = true";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            conn.commit(); // Kết thúc transaction và lưu các thao tác dữ liệu vào cơ sở dữ liệu
            while (rs.next()) {
                Course course = new Course();
                course.setCourseCode(rs.getInt("course_code"));
                course.setCourseName(rs.getString("course_name"));
                course.setCourseDes(rs.getString("course_desc"));
                course.setCourseDuration(rs.getInt("course_duration"));
                course.setCourseFee(rs.getInt("course_fee"));
                course.setStatus(rs.getBoolean("status"));
                course.setCourseCreatedDate(rs.getDate("course_created_date"));
                list.add(course);
            }
            return list;
        } catch (SQLException e) {
            System.out.println(e);
            if (conn != null) {
                try {
                    conn.rollback(); // Hủy bỏ transaction nếu có lỗi xảy ra
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex);
            }
        }
        return null;
    }

    @Override
    public int createOrUpdate(Course course) {
        String sql = "INSERT INTO course(course_code, course_name, course_desc, course_duration, course_fee, status) "
                + "VALUES(?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE"
                + " course_name = VALUES(course_name), course_desc = VALUES(course_desc), course_duration = VALUES(course_duration),"
                + " course_fee = VALUES(course_fee), status = VALUES(status);";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBConnect.getConnection();
            conn.setAutoCommit(false); // Bắt đầu transaction
            ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setInt(1, course.getCourseCode());
            ps.setString(2, course.getCourseName());
            ps.setString(3, course.getCourseDes());
            ps.setInt(4, course.getCourseDuration());
            ps.setInt(5, course.getCourseFee());
            ps.setBoolean(6, true);
            ps.executeUpdate();
            conn.commit(); // Kết thúc transaction và lưu các thao tác dữ liệu vào cơ sở dữ liệu
            rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int generatedKey = rs.getInt(1);
                return generatedKey;
            } else {
                System.out.println("No generated keys were returned.");
                return 0;
            }
        } catch (SQLException e) {
            System.err.println(e);
            if (conn != null) {
                try {
                    conn.rollback(); // Hủy bỏ transaction nếu có lỗi xảy ra
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
        }
        return 0;
    }

    @Override
    public int softDelete(Course course) {
        String sql = "UPDATE course SET status = false WHERE course_code = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBConnect.getConnection();
            conn.setAutoCommit(false); // Bắt đầu transaction
            ps = conn.prepareStatement(sql);
            ps.setInt(1, course.getCourseCode());
            int rs = ps.executeUpdate();
            conn.commit(); // Kết thúc transaction và lưu các thao tác dữ liệu vào cơ sở dữ liệu
            return rs;
        } catch (SQLException e) {
            System.err.println(e);
            if (conn != null) {
                try {
                    conn.rollback(); // Hủy bỏ transaction nếu có lỗi xảy ra
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
        }
        return 0;
    }

    @Override
    public int hardDelete(Course course) {
        String sqlDeleteEnrollment = "DELETE FROM enrollment WHERE course_code = ?";
        String sqlDeleteCourse = "DELETE FROM course WHERE course_code = ?";
        Connection conn = null;
        PreparedStatement psDeleteEnrollment = null;
        PreparedStatement psDeleteCourse = null;
        try {
            conn = DBConnect.getConnection();
            conn.setAutoCommit(false); // Bắt đầu transaction

            // Xóa dữ liệu trong bảng enrollment
            psDeleteEnrollment = conn.prepareStatement(sqlDeleteEnrollment);
            psDeleteEnrollment.setInt(1, course.getCourseCode());
            psDeleteEnrollment.executeUpdate();

            // Xóa dữ liệu trong bảng course
            psDeleteCourse = conn.prepareStatement(sqlDeleteCourse);
            psDeleteCourse.setInt(1, course.getCourseCode());
            int rows = psDeleteCourse.executeUpdate();

            conn.commit(); // Kết thúc transaction và lưu các thao tác dữ liệu vào cơ sở dữ liệu
            return rows;
        } catch (SQLException ex) {
            System.err.println(ex);
            if (conn != null) {
                try {
                    conn.rollback(); // Hủy bỏ transaction nếu có lỗi xảy ra
                } catch (SQLException ex1) {
                    System.err.println(ex1);
                }
            }
        } finally {
            try {
                if (psDeleteEnrollment != null) {
                    psDeleteEnrollment.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
            try {
                if (psDeleteCourse != null) {
                    psDeleteCourse.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
        }
        return 0;
    }

    @Override
    public int recoverSoftDeletedCourse(Course course) {
        String sql = "UPDATE course SET status = true WHERE course_code = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBConnect.getConnection();
            conn.setAutoCommit(false); // Bắt đầu transaction
            ps = conn.prepareStatement(sql);
            ps.setInt(1, course.getCourseCode());
            int rows = ps.executeUpdate();
            conn.commit(); // Kết thúc transaction và lưu các thao tác dữ liệu vào cơ sở dữ liệu
            return rows;
        } catch (SQLException ex) {
            System.err.println(ex);
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
        }
        return 0;
    }

    @Override
    public int getTotalCourse() {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<EnrollmentData> list = null;

        try {
            conn = DBConnect.getConnection();
            String sql = "SELECT  COUNT( course_code) AS total_course FROM course";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            int total = 0;
            while (rs.next()) {
                total = rs.getInt("total_course");
            }
            return total;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        return 0;
    }
}
