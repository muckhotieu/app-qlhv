/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import java.util.List;

import Model.Student;

public interface StudentDAO {

    public List<Student> getList(boolean isDeleted);
    
    public int createOrUpdate(Student student);

    public int softDelete(Student student);

    public int hardDelete(Student student);

    public int recoverSoftDeletedStudent(Student student);

}
