/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Model.Student;
import java.sql.Date;

public class StudentDaoImpl implements StudentDAO {

    @Override
    public List<Student> getList(boolean isDeleted) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Student> list = new ArrayList<>();
        try {
            conn = DBConnect.getConnection();
            String sql = isDeleted ? "SELECT * FROM student WHERE status = false" : "SELECT * FROM student WHERE status = true";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Student student = new Student();
                student.setStudentCode(rs.getInt("student_code"));
                student.setFullName(rs.getString("full_name"));
                student.setDateOfBirth(rs.getDate("date_of_birth"));
                student.setStatus(rs.getBoolean("status"));
                student.setSex(rs.getBoolean("sex"));
                student.setGmail(rs.getString("gmail"));
                student.setPhoneNumber(rs.getString("phone_number"));
                list.add(student);
            }
            return list;
        } catch (SQLException ex) {
            System.out.println("Error occurred: " + ex.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
        }
        return null;
    }

    @Override
    public int createOrUpdate(Student student) {
        String sql = "INSERT INTO student(student_code, full_name, date_of_birth, sex, phone_number, gmail, status) "
                + "VALUES(?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE"
                + " full_name = VALUES(full_name), date_of_birth = VALUES(date_of_birth), sex = VALUES(sex),"
                + " phone_number = VALUES(phone_number), gmail = VALUES(gmail), status = VALUES(status);";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        int generatedKey = 0; // Khởi tạo giá trị mặc định cho generatedKey
        try {
            conn = DBConnect.getConnection();
            ps = conn.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setInt(1, student.getStudentCode());
            ps.setString(2, student.getFullName());
            ps.setDate(3, new Date(student.getDateOfBirth().getTime()));
            ps.setBoolean(4, student.isSex());
            ps.setString(5, student.getPhoneNumber());
            ps.setString(6, student.getGmail());
            ps.setBoolean(7, student.isStatus());
            int affectedRows = ps.executeUpdate();
            if (affectedRows > 0) {
                rs = ps.getGeneratedKeys();
                if (rs.next()) {
                    generatedKey = rs.getInt(1);
                    return generatedKey;
                }
            } else {
                System.err.println("Không có dòng nào được thêm hoặc cập nhật trong cơ sở dữ liệu!");
            }
        } catch (SQLException ex) {
            System.err.println("Error occurred: " + ex.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
        }
        return 0;
    }

    @Override
    public int softDelete(Student student) {
        String sql = "UPDATE student SET status = false WHERE student_code = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBConnect.getConnection();
            conn.setAutoCommit(false); // Bắt đầu transaction
            ps = conn.prepareStatement(sql);
            ps.setInt(1, student.getStudentCode());
            int rs = ps.executeUpdate();
            conn.commit(); // Kết thúc transaction và lưu các thao tác dữ liệu vào cơ sở dữ liệu
            return rs;
        } catch (SQLException ex) {
            System.err.println(ex);
            if (conn != null) {
                try {
                    conn.rollback(); // Hủy bỏ transaction nếu có lỗi xảy ra
                } catch (SQLException e) {
                    System.err.println(e);
                }
            }
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
        }
        return 0;
    }

    @Override
    public int hardDelete(Student student) {
        String sql = "DELETE FROM student WHERE student_code = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBConnect.getConnection();
            conn.setAutoCommit(false); // Bắt đầu transaction
            ps = conn.prepareStatement(sql);
            ps.setInt(1, student.getStudentCode());
            int rs = ps.executeUpdate();
            conn.commit(); // Kết thúc transaction và lưu các thao tác dữ liệu vào cơ sở dữ liệu
            return rs;
        } catch (SQLException ex) {
            System.err.println(ex);
            if (conn != null) {
                try {
                    conn.rollback(); // Hủy bỏ transaction nếu có lỗi xảy ra
                } catch (SQLException e) {
                    System.err.println(e);
                }
            }
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
        }
        return 0;
    }

    @Override
    public int recoverSoftDeletedStudent(Student student) {
        String sql = "UPDATE student SET status = true WHERE student_code = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBConnect.getConnection();
            conn.setAutoCommit(false); // bắt đầu transaction
            ps = conn.prepareStatement(sql);
            ps.setInt(1, student.getStudentCode());
            int rs = ps.executeUpdate();
            conn.commit(); // kết thúc transaction và lưu các thao tác dữ liệu vào cơ sở dữ liệu
            return rs;
        } catch (SQLException ex) {
            System.err.println(ex);
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.err.println(ex);
            }
        }
        return 0;
    }

}
