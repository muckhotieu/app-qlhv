package Dao;

import java.sql.Connection;
import model.Account;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class AccountDAOImpl implements AccountDAO {

    @Override
    public Account login(String userName, String passWord) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        Account account = null;

        try {
            conn = (Connection) DBConnect.getConnection();
            String sql = "SELECT * FROM account WHERE user_name LIKE ? AND password LIKE ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, userName);
            ps.setString(2, passWord);
            rs = ps.executeQuery();
            if (rs.next()) {
                account = new Account();
                account.setAccountCode(rs.getInt("account_code"));
                account.setUserName(rs.getString("user_name"));
                account.setPassword(rs.getString("password"));
                account.setStatus(rs.getBoolean("status"));
            }
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback(); // Hủy bỏ transaction nếu có lỗi xảy ra
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex);
            }
        }
        return account;
    }

    @Override
    public boolean isUsernameExist(String username) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = (Connection) DBConnect.getConnection();

            String sql = "SELECT COUNT(*) AS count FROM account WHERE user_name = ?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            rs = ps.executeQuery();
            if (rs.next()) {
                int count = rs.getInt("count");
                if (count > 0) {
                    return true;
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
            if (conn != null) {
                e.printStackTrace();
            }
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println("Lỗi đóng kết nối");
            }
        }
        return false;
    }

    @Override
    public boolean register(Account account) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean result = false;

        try {
            conn = (Connection) DBConnect.getConnection();
            conn.setAutoCommit(false); // Bắt đầu transaction
            String sql = "INSERT INTO account (user_name, password, status) VALUES (?, ?, ?)";
            ps = conn.prepareStatement(sql);
            ps.setString(1, account.getUserName());
            ps.setString(2, account.getPassword());
            ps.setBoolean(3, account.isStatus());
            int rows = ps.executeUpdate();
            conn.commit(); // Kết thúc transaction và lưu các thao tác dữ liệu vào cơ sở dữ liệu
            if (rows > 0) {
                result = true;
            }
        } catch (SQLException e) {
            System.out.println("loi tao tai khoan");
            if (conn != null) {
                try {
                    conn.rollback(); // Hủy bỏ transaction nếu có lỗi xảy ra
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println("loi dong ket noi");
            }
        }
        return result;
    }
}
