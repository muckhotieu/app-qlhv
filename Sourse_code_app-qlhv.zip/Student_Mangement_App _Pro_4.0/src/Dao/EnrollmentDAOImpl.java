package Dao;

import Bean.EnrollmentData;
import Model.Course;
import Model.Student;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author MUCKHOTAU
 */
public class EnrollmentDAOImpl implements EnrollmentDAO {

    @Override
    public List<EnrollmentData> getEnrollmentList() {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<EnrollmentData> list = null;

        try {
            conn = DBConnect.getConnection();
            String sql = "SELECT enrollment_date, COUNT(*) AS enrollment_count FROM enrollment GROUP BY enrollment_date";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            list = new ArrayList<>();
            while (rs.next()) {
                EnrollmentData dataChartBean = new EnrollmentData();
                dataChartBean.setEnrollmentDate(rs.getString("enrollment_date"));
                dataChartBean.setEnrollmentCount(rs.getInt("enrollment_count"));
                list.add(dataChartBean);
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        return list;
    }

    @Override
    public List<Student> getListStudentInCourse(Course course) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Student> list = null;

        try {
            conn = DBConnect.getConnection();
            String sql = "SELECT * FROM enrollment JOIN student ON enrollment.student_code = student.student_code WHERE enrollment.course_code = ?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, course.getCourseCode());
            rs = ps.executeQuery();
            list = new ArrayList<>();
            while (rs.next()) {
                Student student = new Student();
                student.setStudentCode(rs.getInt("student_code"));
                student.setFullName(rs.getString("full_name"));
                student.setDateOfBirth(rs.getDate("date_of_birth"));
                student.setStatus(rs.getBoolean("status"));
                student.setSex(rs.getBoolean("sex"));
                student.setPhoneNumber(rs.getString("phone_number"));
                list.add(student);
            }
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        return list;
    }

    @Override
    public int getTotalStudent() {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<EnrollmentData> list = null;

        try {
            conn = DBConnect.getConnection();
            String sql = "SELECT  COUNT(DISTINCT student_code) AS total_student FROM enrollment";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            int total = 0;
            while (rs.next()) {
                total = rs.getInt("total_student");
            }
            return total;
        } catch (SQLException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
        return 0;
    }

}
