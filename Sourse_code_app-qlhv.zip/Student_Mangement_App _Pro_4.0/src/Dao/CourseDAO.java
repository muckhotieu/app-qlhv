
package Dao;

import Model.Course;
import java.util.List;

/**
 *
 * @author MUCKHOTAU
 */
public interface CourseDAO {
    public List<Course> getList(boolean isDeleted);

    public int createOrUpdate(Course course);

    public int softDelete(Course course);

    public int hardDelete(Course course);
    
    public int recoverSoftDeletedCourse(Course course);
    
    public int getTotalCourse();

}
