package Main;

import View.AuthenticationManagerJDialog;

public class Main {
	public static void main(String[] args) {
            AuthenticationManagerJDialog authenticationManagerJDialog = new AuthenticationManagerJDialog();
	}
}
