package Utils;

import Model.Course;
import java.util.List;

import javax.swing.table.DefaultTableModel;

import Model.Student;
import java.util.Date;

public class TableModelUntil {

    public DefaultTableModel setTableStudent(List<Student> listItem, String[] listColumn) {
        DefaultTableModel dtm = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }

            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return switch (columnIndex) {
                    case 0 -> Integer.class;
                    case 3 -> Date.class;
                    case 4 -> String.class;
                    default -> super.getColumnClass(columnIndex);
                };
            }
        };
        dtm.setColumnIdentifiers(listColumn);
        int columns = listColumn.length;
        Object[] obj = null;
        int rows = listItem.size();
        if (rows > 0) {
            for (int i = 0; i < rows; i++) {
                Student student = listItem.get(i);
                obj = new Object[columns];
                obj[0] = (i + 1);
                obj[1] = student.getStudentCode();
                obj[2] = student.getFullName();
                obj[3] = student.getDateOfBirth();
                obj[4] = student.isSex() == true ? "Nam" : "Nữ";
                obj[5] = student.getPhoneNumber();
                obj[6] = student.getGmail();
                dtm.addRow(obj);
            }
        }
        return dtm;
    }

    public DefaultTableModel setTableCourse(List<Course> listItem, String[] listColumn) {
        DefaultTableModel dtm = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return switch (columnIndex) {
                    case 3 -> String.class;
                    case 4 -> Integer.class;
                    case 5 -> Date.class;
                    default -> super.getColumnClass(columnIndex);
                };
            }
        };

        dtm.setColumnIdentifiers(listColumn);
        int columns = listColumn.length;
        Object[] obj;
        int rows = listItem.size();
        if (rows > 0) {
            for (int i = 0; i < rows; i++) {
                Course course = listItem.get(i);
                obj = new Object[columns];
                obj[0] = course.getCourseCode();
                obj[1] = course.getCourseName();
                obj[2] = course.getCourseDes();
//                tinh so ngay gio
                int duration = course.getCourseDuration();
                String durationStr;

                if (duration % 60 == 0 && duration / 60 < 24) {
                    durationStr = String.format("%dh", duration / 60);
                } else if (duration % 1440 == 0) {
                    durationStr = String.format("%dd", duration / 1440);
                } else if (duration < 60) {
                    durationStr = String.format("%dm", duration);
                } else if (duration < 1440) {
                    int hours = duration / 60;
                    int minutes = duration % 60;
                    durationStr = String.format("%dh %dm", hours, minutes);
                } else {
                    int days = duration / 1440;
                    int hours = (duration % 1440) / 60;
                    int minutes = duration - days * 1440 - hours * 60;
                    durationStr = String.format("%dd %dh %dm", days, hours, minutes);
                }

                obj[3] = durationStr;
                obj[4] = course.getCourseFee();
                obj[5] = course.getCourseCreatedDate();
                dtm.addRow(obj);

            }
        }
        return dtm;
    }
}
