/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utils;

import Bean.EnrollmentData;
import Service.EnrollmentService;
import Service.EnrollmentServiceImpl;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import java.awt.CardLayout;
import java.awt.Dimension;
import java.util.List;
import javax.swing.JPanel;

/**
 *
 * @author MUCKHOTAU
 */
public class LineChartEnrollmentUntil {

  private final EnrollmentService enrollmentService;

    public LineChartEnrollmentUntil() {
        this.enrollmentService = new EnrollmentServiceImpl();
    }

    private DefaultCategoryDataset createDataset() {
        List<EnrollmentData> listItem = enrollmentService.getEnrollmentList();
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        if (listItem != null) {
            listItem.forEach((var item) -> {
                dataset.addValue(item.getEnrollmentCount(), "Học viên", item.getEnrollmentDate());
            });
        }
        return dataset;
    }

    public void addLineChart(JPanel jpnItem) {
        JFreeChart lineChart = ChartFactory.createLineChart(
                "Biểu đồ ngày lượng học viên đăng kí theo ngày".toUpperCase(),
                "THỜI GIAN", "LƯỢT", createDataset(),
                PlotOrientation.VERTICAL, false, false, false);
        ChartPanel chartPanel = new ChartPanel(lineChart);
        chartPanel.setPreferredSize(new Dimension(jpnItem.getWidth(), jpnItem.getHeight()));
        jpnItem.removeAll();
        jpnItem.setLayout(new CardLayout());
        jpnItem.add(chartPanel);
        jpnItem.validate();
        jpnItem.repaint();
        List<EnrollmentData> listData = enrollmentService.getEnrollmentList();
    }
}
