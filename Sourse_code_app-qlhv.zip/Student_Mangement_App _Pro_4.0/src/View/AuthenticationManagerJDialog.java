package View;

import Controller.AuthenticationManagerController;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JLabel;

import javax.swing.JPanel;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;

public class AuthenticationManagerJDialog extends JDialog {

    private static final int WINDOW_WIDTH = 1200;
    private static final int WINDOW_HEIGHT = 700;
    private static final String WINDOW_TITLE = "Authencation";
    private static final String IMAGE_PATH = "/Images/Avatar.png";

    private JLabel imageLabel;
    private JPanel authPanel;

    public AuthenticationManagerJDialog() {
        createUI();
        AuthenticationManagerController controller = new AuthenticationManagerController(this, authPanel);
        controller.createUI();
    }

    private void createUI() {
        this.setTitle(WINDOW_TITLE);
        this.setSize(WINDOW_WIDTH, WINDOW_HEIGHT);

        JPanel jpnContainer = new JPanel();
        jpnContainer.setBorder(new EmptyBorder(50, 0, 0, 30));
        jpnContainer.setBackground(new Color(51, 0, 102));
        jpnContainer.setLayout(new GridLayout(1, 2));

        //Tạo JPanel chứa ảnh đại diện
        JPanel jpnLogo = new JPanel();
        jpnLogo.setBackground(new Color(51, 0, 102));
        jpnLogo.setLayout(new BorderLayout());
        jpnContainer.add(jpnLogo);
        JLabel jlbLogo = new JLabel("");
        ImageIcon imageIcon = new ImageIcon(MainJFrame.class.getResource("/Images/logo.png"));
        jlbLogo.setIcon(imageIcon);
        jlbLogo.setBorder(new EmptyBorder(0, 0, 200, 0));
        jlbLogo.setHorizontalAlignment(JLabel.CENTER);
        jpnLogo.add(jlbLogo, BorderLayout.CENTER);

        // Tạo JPanel chứa form đăng nhập
        JPanel jpnLogin = new JPanel();
        jpnLogin.setBackground(new Color(51, 0, 102));
        authPanel = new JPanel();
        authPanel.setPreferredSize(new Dimension(500, 550));
        jpnLogin.add(authPanel);
        jpnContainer.add(jpnLogin);

        this.add(jpnContainer);
        this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        this.setLocationRelativeTo(null);
        this.setResizable(false);
        this.setVisible(true);
    }

}
