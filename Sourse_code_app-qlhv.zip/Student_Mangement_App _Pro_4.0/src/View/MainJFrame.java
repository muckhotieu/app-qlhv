package View;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import Controller.ScreenSwitchController;
import Bean.CategoryBean;
import static Controller.ModeColorController.ColorBgMenu;
import static Controller.ModeColorController.ColorForeMenu;

public final class MainJFrame extends JFrame {

    private JPanel jPanel_root;
    private GridBagLayout layout;

    public MainJFrame() {
        this.init();
    }

    public void init() {
        this.setTitle("Student Management");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//khi đóng cửa sổ thì chương trình cũng dừng chạy
        this.setSize(1000, 500);
        this.setLocationRelativeTo(null);

        jPanel_root = new JPanel();//chứa thành phần giao diện người dùng 
        jPanel_root.setBorder(new EmptyBorder(5, 5, 5, 5));//thiết lập viền trống với độ rộng 5 pixel
        jPanel_root.setLayout(new GridBagLayout());

        JPanel jPanelMenu = null;
        jPanelMenu = new JPanel();
        jPanelMenu.setBackground(ColorBgMenu);
        jPanelMenu.setLayout(new GridBagLayout());

        Font fontTitle = new Font("Vivaldi", Font.BOLD, 40);
        JLabel jLabelTitle = new JLabel("<html><span style='text-decoration: underline; padding-bottom: 10px;'>Student Management</span></html>",
                SwingConstants.CENTER);//SwingConstants.center để nó căn giữa theo chiều ngang
//      jLabelTitle.setIcon(new ImageIcon(MainJFrame.class.getResource("/Images/IconQLHV.png")));
        jLabelTitle.setFont(fontTitle);
        jLabelTitle.setForeground(ColorForeMenu);

        GridBagConstraints gbcMenu = new GridBagConstraints();
        gbcMenu.gridx = 0;
        gbcMenu.gridy = 0;
        gbcMenu.weightx = 1;
        gbcMenu.weighty = 0.3;
        gbcMenu.fill = GridBagConstraints.BOTH;
        jPanelMenu.add(jLabelTitle, gbcMenu);

        Font fontSelect = new Font("Arial", Font.PLAIN, 25);
        JPanel jPanelHome = new JPanel();
        jPanelHome.setLayout(new BorderLayout());
        jPanelHome.setBackground(ColorBgMenu);
        JLabel jLabelHome = new JLabel("Home");//SwingConstants.center để nó căn giữa theo chiều ngang
        jLabelHome.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));//cho nó lùi vào 1 đoạn
        jLabelHome.setIcon(new ImageIcon(MainJFrame.class.getResource("/Images/IconHome.png")));
        jPanelHome.add(jLabelHome, BorderLayout.CENTER);
        jLabelHome.setFont(fontSelect);
        jLabelHome.setForeground(ColorForeMenu);
        gbcMenu.gridx = 0;
        gbcMenu.gridy = 1;
        gbcMenu.weightx = 1;
        gbcMenu.weighty = 0.1;
        gbcMenu.fill = GridBagConstraints.BOTH;
        jPanelMenu.add(jPanelHome, gbcMenu);

        JPanel jPanelStudent = new JPanel();
        jPanelStudent.setLayout(new BorderLayout());
        jPanelStudent.setBackground(ColorBgMenu);
        JLabel jLabelStudent = new JLabel(" Student Management");//SwingConstants.center để nó căn giữa theo chiều ngang
        jLabelStudent.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));//cho nó lùi vào 1 đoạn
        jLabelStudent.setIcon(new ImageIcon(MainJFrame.class.getResource("/Images/IconStudent.png")));
        jPanelStudent.add(jLabelStudent, BorderLayout.CENTER);
        jLabelStudent.setFont(fontSelect);
        jLabelStudent.setForeground(ColorForeMenu);
        gbcMenu.gridx = 0;
        gbcMenu.gridy = 2;
        gbcMenu.weightx = 1;
        gbcMenu.weighty = 0.1;
        gbcMenu.fill = GridBagConstraints.BOTH;
        jPanelMenu.add(jPanelStudent, gbcMenu);

        JPanel jPanelCourse = new JPanel();
        jPanelCourse.setLayout(new BorderLayout());
        jPanelCourse.setBackground(ColorBgMenu);
        JLabel jLabelCourse = new JLabel("Course Management");//SwingConstants.center để nó căn giữa theo chiều ngang
        jLabelCourse.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));//cho nó lùi vào 1 đoạn
        jLabelCourse.setIcon(new ImageIcon(MainJFrame.class.getResource("/Images/IconCourse.png")));
        jPanelCourse.add(jLabelCourse, BorderLayout.CENTER);
        jLabelCourse.setFont(fontSelect);
        jLabelCourse.setForeground(ColorForeMenu);
        gbcMenu.gridx = 0;
        gbcMenu.gridy = 3;
        gbcMenu.weightx = 1;
        gbcMenu.weighty = 0.1;
        gbcMenu.fill = GridBagConstraints.BOTH;
        jPanelMenu.add(jPanelCourse, gbcMenu);

        JPanel jPanelStudentRestoration = new JPanel();
        jPanelStudentRestoration.setLayout(new BorderLayout());
        jPanelStudentRestoration.setBackground(ColorBgMenu);
        JLabel jLabelStudentRestoration = new JLabel("Student Restoration");//SwingConstants.center để nó căn giữa theo chiều ngang
        jLabelStudentRestoration.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));//cho nó lùi vào 1 đoạn
        jLabelStudentRestoration.setIcon(new ImageIcon(MainJFrame.class.getResource("/Images/IconRestoST.png")));
        jPanelStudentRestoration.add(jLabelStudentRestoration, BorderLayout.CENTER);
        jLabelStudentRestoration.setFont(fontSelect);
        jLabelStudentRestoration.setForeground(ColorForeMenu);
        gbcMenu.gridx = 0;
        gbcMenu.gridy = 4;
        gbcMenu.weightx = 1;
        gbcMenu.weighty = 0.1;
        gbcMenu.fill = GridBagConstraints.BOTH;
        jPanelMenu.add(jPanelStudentRestoration, gbcMenu);

        JPanel jPanelCourseRestoration = new JPanel();
        jPanelCourseRestoration.setLayout(new BorderLayout());
        jPanelCourseRestoration.setBackground(ColorBgMenu);
        JLabel jLabelCourseRestoration = new JLabel("Course Restoration");//SwingConstants.center để nó căn giữa theo chiều ngang
        jLabelCourseRestoration.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));//cho nó lùi vào 1 đoạn
        jLabelCourseRestoration.setIcon(new ImageIcon(MainJFrame.class.getResource("/Images/IconData.png")));
        jPanelCourseRestoration.add(jLabelCourseRestoration, BorderLayout.CENTER);
        jLabelCourseRestoration.setFont(fontSelect);
        jLabelCourseRestoration.setForeground(ColorForeMenu);
        gbcMenu.gridx = 0;
        gbcMenu.gridy = 5;
        gbcMenu.weightx = 1;
        gbcMenu.weighty = 0.1;
        gbcMenu.fill = GridBagConstraints.BOTH;
        jPanelMenu.add(jPanelCourseRestoration, gbcMenu);

        JPanel jpnSetting = new JPanel();
        jpnSetting.setLayout(new BorderLayout());
        jpnSetting.setBackground(ColorBgMenu);
        JLabel jlbSetting = new JLabel("Settings");//SwingConstants.center để nó căn giữa theo chiều ngang
        jlbSetting.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));//cho nó lùi vào 1 đoạn
        jlbSetting.setIcon(new ImageIcon(MainJFrame.class.getResource("/Images/IconSetting.png")));
        jpnSetting.add(jlbSetting, BorderLayout.CENTER);
        jlbSetting.setFont(fontSelect);
        jlbSetting.setForeground(ColorForeMenu);
        gbcMenu.gridx = 0;
        gbcMenu.gridy = 6;
        gbcMenu.weightx = 1;
        gbcMenu.weighty = 0.1;
        gbcMenu.fill = GridBagConstraints.BOTH;
        jPanelMenu.add(jpnSetting, gbcMenu);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbcMenu.weightx = 0.2;
        gbc.weightx = 0.1;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;
        jPanel_root.add(jPanelMenu, gbc);

        JPanel jPanelView = new JPanel();
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 0.9;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.BOTH;
        jPanel_root.add(jPanelView, gbc);

        ScreenSwitchController controller = new ScreenSwitchController(jPanelView);
        controller.setView(jPanelHome, jLabelHome);
        List<CategoryBean> listItem = new ArrayList<>();
        listItem.add(new CategoryBean("Home", jPanelHome, jLabelHome));
        listItem.add(new CategoryBean("Student", jPanelStudent, jLabelStudent));
        listItem.add(new CategoryBean("Course", jPanelCourse, jLabelCourse));
        listItem.add(new CategoryBean("StudentRestoration", jPanelStudentRestoration, jLabelStudentRestoration));
        listItem.add(new CategoryBean("CourseRestoration", jPanelCourseRestoration, jLabelCourseRestoration));
        listItem.add(new CategoryBean("Setting", jpnSetting, jlbSetting));
        controller.setEvent(listItem);
        // Đặt JFrame không cho phép phóng to/thu nhỏ cửa sổ
        this.setResizable(false);
        // Đặt JFrame vào chế độ fullscreen
//        this.setUndecorated(true);
        this.add(jPanel_root);
        this.setVisible(true);//hiển thị JFrame lên màn hình
    }

    public void resetFrame() {
        this.getContentPane().removeAll(); // Xóa hết các thành phần đang có trên giao diện của JFrame
        this.init();
        this.revalidate(); // Cập nhật lại giao diện của JFrame
        this.repaint(); // Vẽ lại giao diện của JFrame
    }
}
