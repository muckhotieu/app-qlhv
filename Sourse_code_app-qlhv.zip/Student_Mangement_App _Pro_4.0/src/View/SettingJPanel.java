/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import Controller.ModeColorController;
import static Controller.ModeColorController.BorderInput;
import static Controller.ModeColorController.ColorBg;
import static Controller.ModeColorController.ColorForeHelp;
import static Controller.ModeColorController.ColorText;
import Controller.SettingController;
import Utils.RoundedButtonUntil;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.EmptyBorder;

/**
 *
 * @author DELL
 */
public final class SettingJPanel extends JPanel {

    private JRadioButton jrBright;
    private JRadioButton jrDark;
    private ButtonGroup btnGroup;
    private JComboBox<String> jcbLang;
    private RoundedButtonUntil btnLogout;
    private JButton btnHelp;

    public SettingJPanel() {
        init();
        SettingController controller = new SettingController(jrBright, jrDark,btnLogout);
        controller.setEvent();
    }

    public void init() {
        this.setSize(800, 700);
        JPanel jpnContainer = new JPanel();
        jpnContainer.setBorder(new EmptyBorder(0, 20, 0,20));
//        jpnContainer.setBackground(new Color(51,0,102));
        jpnContainer.setLayout(new BorderLayout());

        JPanel jpnTitle = new JPanel();
        jpnTitle.setBackground(ColorBg);
        JLabel jlbtitle = new JLabel("Settings");
        jlbtitle.setForeground(ColorText);
        jlbtitle.setFont(new Font("Arial", Font.BOLD, 30));
//        jlbtitle.setForeground(new Color(0, 0, 0));
        jpnTitle.add(jlbtitle);
        jpnContainer.add(jpnTitle, BorderLayout.NORTH);

        JPanel jpnSetting = new JPanel();
        jpnSetting.setBackground(ColorBg);
        jpnSetting.setLayout(new BorderLayout());

        JPanel jpnLeft = new JPanel();
        jpnLeft.setBackground(ColorBg);
        jpnLeft.setPreferredSize(new Dimension(160, jpnLeft.getPreferredSize().height));
        jpnSetting.add(jpnLeft, BorderLayout.WEST);

        JPanel jpnCenter = new JPanel();
        jpnCenter.setLayout(new GridLayout(6, 1));
        jpnCenter.setBackground(ColorBg);
        jpnSetting.add(jpnCenter, BorderLayout.CENTER);

        Font font = new Font("Arial", Font.PLAIN, 20);

        JPanel jpnChangeBg = new JPanel();
        jpnChangeBg.setLayout(new GridLayout(1, 2));
        jpnChangeBg.setBackground(ColorBg);
        JLabel jlbChangeBg = new JLabel("Đổi màu nền:");
        jlbChangeBg.setForeground(ColorText);
        jlbChangeBg.setFont(font);
        jpnChangeBg.add(jlbChangeBg);
        JPanel jpnButton = new JPanel();
        jpnButton.setLayout(new GridLayout(1, 2));
        jrBright = new JRadioButton("Sáng");
        jrBright.setFont(font);
        jrBright.setBorder(new EmptyBorder(0, 45, 0, 0));
        jrBright.setForeground(ColorText);
        jrBright.setBackground(ColorBg);
        jrDark = new JRadioButton("Tối");
        jrDark.setFont(font);
        jrDark.setBorder(new EmptyBorder(0, 45, 0, 0));
        jrDark.setForeground(ColorText);
        jrDark.setBackground(ColorBg);
        
        if (ModeColorController.ModeColor) {
            jrBright.setSelected(true);
        }else { 
            jrDark.setSelected(true);
        }
        btnGroup = new ButtonGroup();
        btnGroup.add(jrDark);
        btnGroup.add(jrBright);
        jpnButton.add(jrBright);
        jpnButton.add(jrDark);
        jpnChangeBg.add(jpnButton);
        jpnCenter.add(jpnChangeBg);
        
        JPanel jpnLanguage = new JPanel();
        jpnLanguage.setLayout(new GridLayout(1, 2));
        jpnLanguage.setBackground(ColorBg);
        JLabel jlbLang = new JLabel("Language:");
        jlbLang.setBorder(new EmptyBorder(0, 0, 0, 0));
        jlbLang.setForeground(ColorText);
        jlbLang.setFont(font);
        jpnLanguage.add(jlbLang);
        String[] languages = {"VietNam", "English", "French", "Italia"};
        JPanel jpnJCB = new JPanel();
        jpnJCB.setBorder(new EmptyBorder(30, 0, 0, 0));
        jpnJCB.setBackground(ColorBg);
        jcbLang = new JComboBox<>(languages);
        jcbLang.setFont(font);
        jcbLang.setBackground(ColorBg);
        jcbLang.setForeground(ColorText);
        jcbLang.setLightWeightPopupEnabled(true);
        jcbLang.setBorder(BorderFactory.createLineBorder(BorderInput));
        jcbLang.setPreferredSize(new Dimension(250, 40));
        jpnJCB.add(jcbLang);
        jpnLanguage.add(jpnJCB);
        jpnCenter.add(jpnLanguage);

        JPanel jpnHelp = new JPanel();
        jpnHelp.setLayout(new GridLayout(1, 2));
        jpnHelp.setBackground(ColorBg);
        JLabel jlbHelp = new JLabel("Help:");
        jlbHelp.setForeground(ColorText);
        jlbHelp.setBorder(new EmptyBorder(0, 0, 0, 70));
        jlbHelp.setFont(font);
        jpnHelp.add(jlbHelp);
        btnHelp = new JButton("<html><u>Send a message</u></html>");
        btnHelp.setFont(font);
        btnHelp.setForeground(ColorForeHelp);
        btnHelp.setPreferredSize(new Dimension(230, 40));
        btnHelp.setBorderPainted(false); // tắt viền
        btnHelp.setContentAreaFilled(false);
        jpnHelp.add(btnHelp);
        jpnCenter.add(jpnHelp);

        JPanel jpnLogout = new JPanel();
        jpnLogout.setBackground(ColorBg);
        btnLogout = new RoundedButtonUntil("Đăng xuất");
        btnLogout.setBorder(BorderFactory.createLineBorder(BorderInput));
        btnLogout.setFont(font);
        btnLogout.setForeground(ColorText);
        btnLogout.setBackground(ColorBg);

        jpnLogout.add(btnLogout);
        jpnCenter.add(jpnLogout);

        jpnContainer.add(jpnSetting, BorderLayout.CENTER);

        JPanel jpnRight = new JPanel();
        jpnRight.setBackground(ColorBg);
        jpnRight.setPreferredSize(new Dimension(160, jpnLeft.getPreferredSize().height));
        jpnSetting.add(jpnRight, BorderLayout.EAST);

        this.setLayout(new BorderLayout());
        this.add(jpnContainer, BorderLayout.CENTER);

//        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
//        this.setLocationRelativeTo(null);
//        this.setVisible(true);
    }
//
//    public static void main(String[] args) {
//        new SettingJPanel();
//    }
}
