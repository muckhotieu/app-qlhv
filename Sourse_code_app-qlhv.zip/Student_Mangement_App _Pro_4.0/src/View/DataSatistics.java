package View;

import javax.swing.JPanel;

public class DataSatistics extends JPanel {

}
