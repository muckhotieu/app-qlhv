package View;

import static Controller.ModeColorController.BorderInput;
import static Controller.ModeColorController.ColorBgDelete;
import static Controller.ModeColorController.ColorBgSubmit;
import static Controller.ModeColorController.ColorForeSD;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

import Controller.StudentController;
import Model.Student;
import Utils.RoundedButtonUntil;
import com.toedter.calendar.JDateChooser;
import javax.swing.BorderFactory;
import javax.swing.border.LineBorder;

public class StudentJFrame extends JFrame {

    private JPanel jPanel_root;
    private JTextField jtfStudentCode;
    private JTextField jtfFullName;
    private JTextField jtfNumberPhone;
    private ButtonGroup buttonGroup;
    private RoundedButtonUntil btnSubmit;
    private RoundedButtonUntil btnDelete;
    private JRadioButton jrFemale;
    private JRadioButton jrMale;
    private JCheckBox jcbActive;
    private JTextArea jtaGmail;
    private JLabel jlbMsg;
    private JDateChooser jdcDateOfBirth;

    public StudentJFrame(Student student) {
        this.init();
        StudentController controller = new StudentController(this, btnSubmit, btnDelete, jtfStudentCode, jtfFullName,
                jdcDateOfBirth, jrMale, jrFemale, jcbActive, jtfNumberPhone, jtaGmail, jlbMsg);
        controller.setView(student);
        controller.setEvent();
    }

    public final void init() {
        this.setSize(800, 600);
        this.setLocationRelativeTo(null);

        JPanel jPanelMain = new JPanel();
        jPanelMain.setBorder(new EmptyBorder(20, 20, 20, 20));
        jPanelMain.setLayout(new BorderLayout());

        JPanel jPanelController = new JPanel();
        jPanelController.setPreferredSize(new Dimension(getWidth(), 60));

        jlbMsg = new JLabel("");
        jlbMsg.setBorder(new EmptyBorder(0, 0, 20, 0));
        jlbMsg.setForeground(new Color(250, 128, 114));
        jlbMsg.setFont(new Font("Arial", Font.PLAIN, 30));
        JPanel jPanelPress = new JPanel();
        btnSubmit = new RoundedButtonUntil("Submit");
        btnSubmit.setFont(new Font("Arial", Font.PLAIN, 20));
        btnSubmit.setBackground(ColorBgSubmit);
        btnSubmit.setForeground(ColorForeSD);
        btnDelete = new RoundedButtonUntil("Delete");
        btnDelete.setFont(new Font("Arial", Font.PLAIN, 20));
        btnDelete.setBackground(ColorBgDelete);
        btnDelete.setForeground(ColorForeSD);
        jPanelPress.add(btnSubmit);
        jPanelPress.add(btnDelete);

        jPanelController.setLayout(new BorderLayout());
        jPanelController.add(jlbMsg, BorderLayout.WEST);
        jPanelController.add(jPanelPress, BorderLayout.EAST);

        JPanel jPanelContent = new JPanel();
        jPanelContent.setLayout(new BorderLayout());

        JPanel jPanelInfor = new JPanel();
        TitledBorder titledBorder = new TitledBorder(null, "Thông tin học viên", TitledBorder.LEADING, TitledBorder.TOP, null, null);
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 20));
        jPanelInfor.setBorder(titledBorder);
        jPanelContent.add(jPanelInfor, BorderLayout.CENTER);

        jPanelInfor.setLayout(new GridLayout(1, 2));
        JPanel jPanelInforLeft = new JPanel();
        jPanelInforLeft.setLayout(new FlowLayout());

        JLabel jlbStudentCode = new JLabel("Student Code:");
        jtfStudentCode = new JTextField();
        jtfStudentCode.setPreferredSize(new Dimension(240, 30));
        jtfStudentCode.setEditable(false);

        jPanelInforLeft.add(jlbStudentCode);
        jPanelInforLeft.add(jtfStudentCode);
        jlbStudentCode.setBorder(new EmptyBorder(30, 0, 30, 10));
        jlbStudentCode.setFont(new Font("Arial", Font.BOLD, 15));
        jtfStudentCode.setFont(new Font("Arial", Font.BOLD, 15));

        JLabel jlbFullName = new JLabel("Full Name:");
        jtfFullName = new JTextField();
        jtfFullName.setPreferredSize(new Dimension(240, 30));
        jtfFullName.setBorder(BorderFactory.createLineBorder(BorderInput));
        jPanelInforLeft.add(jlbFullName);
        jPanelInforLeft.add(jtfFullName);
        jlbFullName.setBorder(new EmptyBorder(30, 0, 30, 36));
        jlbFullName.setFont(new Font("Arial", Font.BOLD, 15));
        jtfFullName.setFont(new Font("Arial", Font.BOLD, 15));

        JLabel jlbDateOfBirth = new JLabel("Date of birth:");
        jdcDateOfBirth = new JDateChooser();
        jdcDateOfBirth.setPreferredSize(new Dimension(240, 30));
         jdcDateOfBirth.setBorder(BorderFactory.createLineBorder(BorderInput));
        jPanelInforLeft.add(jlbDateOfBirth);
        jPanelInforLeft.add(jdcDateOfBirth);
        jlbDateOfBirth.setBorder(new EmptyBorder(30, 0, 30, 15));
        jlbDateOfBirth.setFont(new Font("Arial", Font.BOLD, 15));
        jdcDateOfBirth.setFont(new Font("Arial", Font.BOLD, 15));

        JLabel jlbNumberPhone = new JLabel("Phone Number:");
        jtfNumberPhone = new JTextField();
        jtfNumberPhone.setBorder(BorderFactory.createLineBorder(BorderInput));
        jtfNumberPhone.setPreferredSize(new Dimension(240, 30));
        jPanelInforLeft.add(jlbNumberPhone);
        jPanelInforLeft.add(jtfNumberPhone);
        jlbNumberPhone.setBorder(new EmptyBorder(30, 0, 30, 0));
        jlbNumberPhone.setFont(new Font("Arial", Font.BOLD, 15));
        jtfNumberPhone.setFont(new Font("Arial", Font.BOLD, 15));

        JPanel jPanelInforRight = new JPanel();
        jPanelInforRight.setLayout(new FlowLayout());
        JLabel jLabelGenerate = new JLabel("Generate:");
        jrFemale = new JRadioButton("Nữ");
        buttonGroup = new ButtonGroup();
        buttonGroup.add(jrFemale);
        jrMale = new JRadioButton("Nam");
        buttonGroup.add(jrMale);
        jPanelInforRight.add(jLabelGenerate);
        jPanelInforRight.add(jrMale);
        jPanelInforRight.add(jrFemale);
        jLabelGenerate.setBorder(new EmptyBorder(30, 0, 30, 0));
        jrMale.setBorder(new EmptyBorder(0, 60, 0, 60));

        jLabelGenerate.setFont(new Font("Arial", Font.BOLD, 15));
        jrFemale.setFont(new Font("Arial", Font.BOLD, 15));
        jrMale.setFont(new Font("Arial", Font.BOLD, 15));

        JLabel jLabelAdress = new JLabel("Gmail:");
        jtaGmail = new JTextArea();
        jtaGmail.setBorder(new LineBorder(BorderInput,1));
        jPanelInforRight.add(jLabelAdress);
        jPanelInforRight.add(jtaGmail);
        jtaGmail.setPreferredSize(new Dimension(250, 60));
        jLabelAdress.setBorder(new EmptyBorder(30, 35, 30, 10));
        jLabelAdress.setFont(new Font("Arial", Font.BOLD, 15));
        jtaGmail.setFont(new Font("Arial", Font.BOLD, 15));

//        JLabel jLabelStatus = new JLabel("Status:");
//        jcbActive = new JCheckBox();
//        jcbActive.setSelected(true);
//        jcbActive.setEnabled(false);
//        jPanelInforRight.add(jLabelStatus);
//        jPanelInforRight.add(jcbActive);
//        jLabelStatus.setBorder(new EmptyBorder(30, 0, 30, 20));
//        jLabelStatus.setFont(new Font("Times New Roman", Font.BOLD, 15));

        JLabel jLabelSpace = new JLabel("");
        jPanelInforRight.add(jLabelSpace);
        jLabelSpace.setBorder(new EmptyBorder(30, 165, 30, 20));

        jPanelInfor.add(jPanelInforLeft);
        jPanelInfor.add(jPanelInforRight);

        jPanelMain.add(jPanelController, BorderLayout.NORTH);
        jPanelMain.add(jPanelContent, BorderLayout.CENTER);

        this.setLayout(new BorderLayout());
        this.add(jPanelMain, BorderLayout.CENTER);

        this.setResizable(false);
        this.setVisible(true);
    }
}
