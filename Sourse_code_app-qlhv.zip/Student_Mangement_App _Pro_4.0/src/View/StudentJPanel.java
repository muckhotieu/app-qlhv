package View;

import static Controller.ModeColorController.ColorBgAdd;
import static Controller.ModeColorController.ColorBgExport;
import static Controller.ModeColorController.ColorForeAE;
import Controller.StudentManagementController;

import Utils.RoundedButtonUntil;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JTextField;

public final class StudentJPanel extends JPanel {
    private JTextField jtfSearch;
    private RoundedButtonUntil btnAdd;
    private JPanel jpnInfor;
    private RoundedButtonUntil btnExport;
    public static StudentManagementController  pageStudentController;
    public StudentJPanel() {
        this.init();
        pageStudentController = new StudentManagementController(jpnInfor, btnAdd, jtfSearch, btnExport);
        pageStudentController.renderData(false);
        pageStudentController.setEven();
    }

    public void init() {
        this.setSize(900, 700);

        JPanel jPanelContent = new JPanel();
        jPanelContent.setLayout(new BorderLayout());
        jPanelContent.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel jPanelController = new JPanel();
        jPanelController.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        jPanelController.setLayout(new BorderLayout());
        jtfSearch = new JTextField();
        jtfSearch.setFont(new Font("Arial",Font.PLAIN,20));
        jtfSearch.setPreferredSize(new Dimension(250, 30));
        
        btnAdd = new RoundedButtonUntil("Add");
        btnAdd.setForeground(ColorForeAE);
        btnAdd.setBackground(ColorBgAdd);
        btnAdd.setFont(new Font("Arial", Font.BOLD, 20));
        btnAdd.setPreferredSize(new Dimension(120, 40));
        btnExport=new RoundedButtonUntil("Export");
        btnExport.setForeground(ColorForeAE);
        btnExport.setBackground(ColorBgExport);
        btnExport.setFont(new Font("Arial", Font.BOLD, 20));
        btnExport.setPreferredSize(new Dimension(120, 40));
//        btnExport.addMouseListener(new ButtonController());
        
        JPanel jpnButtons = new JPanel(new GridLayout(1, 2, 10, 0));
         jpnButtons.add(btnExport);
        jpnButtons.add(btnAdd);
        jPanelController.add(jpnButtons, BorderLayout.EAST);
        jPanelController.add(jtfSearch,BorderLayout.WEST);

        jpnInfor = new JPanel();
        jPanelContent.add(jPanelController, BorderLayout.NORTH);
        jPanelContent.add(jpnInfor, BorderLayout.CENTER);

        this.setLayout(new BorderLayout());
        this.add(jPanelContent, BorderLayout.CENTER);
        this.setVisible(true);
    }

}

