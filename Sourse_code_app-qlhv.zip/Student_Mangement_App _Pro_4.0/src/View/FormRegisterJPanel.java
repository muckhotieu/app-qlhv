package View;

import Utils.RoundedButtonUntil;
import controller.FormRegisterController;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public final class FormRegisterJPanel extends JPanel {

    private JPasswordField jpfPassword;
    private JPasswordField jpfConfirmPassword;
    private JTextField jtfUserName;
    private JLabel jLabelError;
    private JLabel jlbMsg;
    private RoundedButtonUntil btnSubmit;
    private RoundedButtonUntil btnReset;
    private RoundedButtonUntil btnLogin;

    public FormRegisterJPanel() {
        this.init();
        FormRegisterController controller = new FormRegisterController(btnSubmit, btnReset, btnLogin, jtfUserName, jpfPassword,
                jpfConfirmPassword, jlbMsg, this);
        controller.setEvent();

    }

    public void init() {
        this.setSize(500, 600);
        JLabel jLabelTitle = new JLabel("Sign Up");
        jLabelTitle.setForeground(new Color(255, 255, 255));
        jLabelTitle.setFont(new Font("Arial", Font.BOLD, 40));
        jLabelTitle.setHorizontalAlignment(SwingConstants.CENTER);

        JPanel jPanelSignUp = new JPanel();
        jPanelSignUp.setBackground(new Color(51, 0, 102));
        jPanelSignUp.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
        jPanelSignUp.setLayout(new BorderLayout());

        JPanel jPanelWrite = new JPanel();
        jPanelWrite.setBackground(new Color(51, 0, 102));
        jPanelWrite.setPreferredSize(new Dimension(200, 300));
        jPanelWrite.setLayout(new GridLayout(7, 1));
        JLabel jLabelUser = new JLabel("User name");
        jLabelUser.setForeground(new Color(255, 255, 255));
        jLabelUser.setFont(new Font("Arial", Font.PLAIN, 20));

        jtfUserName = new JTextField();
        jtfUserName.setForeground(new Color(255, 255, 255));
        jtfUserName.setFont(new Font("Arial", Font.PLAIN, 20));
        jtfUserName.setBorder(null); // loại bỏ đường viền hiện có
        jtfUserName.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.white)); // tạo đường viền mới
        jtfUserName.setOpaque(false);

        JLabel jLabelPassword = new JLabel("Password");
        jLabelPassword.setForeground(new Color(255, 255, 255));
        jLabelPassword.setFont(new Font("Arial", Font.PLAIN, 20));
        jpfPassword = new JPasswordField();
        jpfPassword.setForeground(new Color(255, 255, 255));
        jpfPassword.setFont(new Font("Arial", Font.PLAIN, 20));
        jpfPassword.setBorder(null); // loại bỏ đường viền hiện có
        jpfPassword.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.white)); // tạo đường viền mới
        jpfPassword.setOpaque(false);

        JLabel jLabelConfirm = new JLabel("Confirm Password");
        jLabelConfirm.setForeground(new Color(255, 255, 255));
        jLabelConfirm.setFont(new Font("Arial", Font.PLAIN, 20));
        jpfConfirmPassword = new JPasswordField();
        jpfConfirmPassword.setForeground(new Color(255, 255, 255));
        jpfConfirmPassword.setFont(new Font("Arial", Font.PLAIN, 20));
        jpfConfirmPassword.setBorder(null); // loại bỏ đường viền hiện có
        jpfConfirmPassword.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, Color.white)); // tạo đường viền mới
        jpfConfirmPassword.setOpaque(false);

        jlbMsg = new JLabel("");
        jlbMsg.setForeground(new Color(255, 128, 0));

        jPanelWrite.add(jLabelUser);
        jPanelWrite.add(jtfUserName);
        jPanelWrite.add(jLabelPassword);
        jPanelWrite.add(jpfPassword);
        jPanelWrite.add(jLabelConfirm);
        jPanelWrite.add(jpfConfirmPassword);
        jPanelWrite.add(jlbMsg);

        jPanelSignUp.add(jPanelWrite, BorderLayout.NORTH);

        JPanel jPanelPress = new JPanel();
        jPanelPress.setBackground(new Color(51, 0, 102));
        jPanelPress.setBorder(BorderFactory.createEmptyBorder(50, 0, 50, 0));
        jPanelPress.setLayout(new BorderLayout());
        jPanelSignUp.add(jPanelPress, BorderLayout.CENTER);
        btnSubmit = new RoundedButtonUntil("Submit");
        btnSubmit.setBackground(new Color(51, 0, 102));
        btnSubmit.setForeground(new Color(255, 255, 255));
        btnSubmit.setFont(new Font("Arial", Font.BOLD, 20));
        btnReset = new RoundedButtonUntil("Reset");
        btnReset.setBackground(new Color(51, 0, 102));
        btnReset.setForeground(new Color(255, 255, 255));
        btnReset.setFont(new Font("Arial", Font.BOLD, 20));
        btnSubmit.setPreferredSize(new Dimension(100, btnSubmit.getPreferredSize().height));
        btnReset.setPreferredSize(new Dimension(100, btnReset.getPreferredSize().height));
        jPanelPress.add(btnSubmit, BorderLayout.WEST);
        jPanelPress.add(btnReset, BorderLayout.EAST);

        JPanel jPanelLogin = new JPanel();
        jPanelLogin.setBackground(new Color(51, 0, 102));
        jPanelSignUp.add(jPanelLogin, BorderLayout.SOUTH);
        jPanelLogin.setLayout(new BorderLayout());
        JLabel jLabelNote = new JLabel("Do you already have an account?");
        jLabelNote.setForeground(new Color(255, 255, 255));
        jLabelNote.setFont(new Font("Arial", Font.BOLD, 17));
        btnLogin = new RoundedButtonUntil("Log in");
        btnLogin.setBackground(new Color(51, 0, 102));
        btnLogin.setForeground(new Color(255, 255, 255));
        btnLogin.setFont(new Font("Arial", Font.BOLD, 17));

        jPanelLogin.add(jLabelNote, BorderLayout.WEST);
        jPanelLogin.add(btnLogin, BorderLayout.EAST);

        this.setBackground(new Color(51, 0, 102));
        this.setLayout(new BorderLayout());
        this.add(jPanelSignUp, BorderLayout.CENTER);
        this.add(jLabelTitle, BorderLayout.NORTH);
        this.setVisible(true);
    }

}
