package View;

import Controller.CourseController;
import static Controller.ModeColorController.BorderInput;
import static Controller.ModeColorController.ColorBgDelete;
import static Controller.ModeColorController.ColorBgExport;
import static Controller.ModeColorController.ColorBgSubmit;
import static Controller.ModeColorController.ColorForeSD;
import Model.Course;
import Utils.RoundedButtonUntil;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public final class CourseJFrame extends JFrame {

    private JTextField jtfSearch;
    private JTextField jtfCourseCode;
    private JTextField jtfCourseName;
    private JTextArea jtrDescribe;
    private JTextField jtfCourseDuration;
    private JTextField jtfCourseFee;
    private RoundedButtonUntil btnExport;
    private RoundedButtonUntil btnSubmit;
    private RoundedButtonUntil btnDelete;
    private JLabel jlbMsg;
    private JLabel jlbDescribe;

    public CourseJFrame(Course course) {
        this.init();
        CourseController controller = new CourseController(btnSubmit, btnExport, btnDelete, jtfCourseCode, jtfCourseName, jtrDescribe,
                jtfCourseDuration, jtfCourseFee, jlbMsg, this);
        controller.setView(course);
        controller.setEvent();
    }

    public void init() {
        this.setSize(800, 500);
        this.setLocationRelativeTo(null);

        JPanel jpnRoot = new JPanel();
        jpnRoot.setBorder(new EmptyBorder(20, 20, 20, 20));
        jpnRoot.setLayout(new BorderLayout());

        JPanel jpnController = new JPanel();
        jpnController.setPreferredSize(new Dimension(getWidth(), 60));

        jlbMsg = new JLabel("");
        jlbMsg.setBorder(new EmptyBorder(0, 0, 20, 0));
        jlbMsg.setForeground(new Color(250, 128, 114));
        jlbMsg.setFont(new Font("Arial", Font.PLAIN, 30));
        
        JPanel jpnPress = new JPanel();
        btnSubmit = new RoundedButtonUntil("Submit");
        btnSubmit.setFont(new Font("Arial", Font.PLAIN, 20));
        btnSubmit.setBackground(ColorBgSubmit);
        btnSubmit.setForeground(ColorForeSD);
        
        btnExport = new RoundedButtonUntil("Export");
        btnExport.setFont(new Font("Arial", Font.PLAIN, 20));
        btnExport.setBackground(ColorBgExport);
        btnExport.setForeground(ColorForeSD);
        
        btnDelete = new RoundedButtonUntil("Delete");
        btnDelete.setFont(new Font("Arial", Font.PLAIN, 20));
        btnDelete.setBackground(ColorBgDelete);
        btnDelete.setForeground(ColorForeSD);
        jpnPress.add(btnSubmit);
        jpnPress.add(btnDelete);
        jpnPress.add( btnExport);

        jpnController.setLayout(new BorderLayout());
        jpnController.add(jlbMsg, BorderLayout.WEST);
        jpnController.add(jpnPress, BorderLayout.EAST);

        JPanel jpnContent = new JPanel();
        jpnContent.setLayout(new BorderLayout());

        JPanel jpnInfor = new JPanel();
        TitledBorder titledBorder = new TitledBorder(null, "Thông tin khóa học",
                TitledBorder.LEADING, TitledBorder.TOP, null, null);
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 20));
        jpnInfor.setBorder(titledBorder);
        jpnContent.add(jpnInfor, BorderLayout.CENTER);
        jpnInfor.setLayout(new FlowLayout());

        JLabel jlbCourseCode = new JLabel("Mã khóa học:");
        jtfCourseCode = new JTextField();
        jlbCourseCode.setBorder(new EmptyBorder(10, 0, 10, 0));
        jtfCourseCode.setPreferredSize(new Dimension(250, 30));
        jtfCourseCode.setEditable(false);

        jpnInfor.add(jlbCourseCode);
        jpnInfor.add(jtfCourseCode);
        jlbCourseCode.setFont(new Font("Arial", Font.BOLD, 15));
        jtfCourseCode.setFont(new Font("Arial", Font.BOLD, 15));

        JLabel jlbCourseName = new JLabel("Tên khóa:");
        jtfCourseName = new JTextField();
        jlbCourseName.setBorder(new EmptyBorder(10, 20, 10, 20));
        jtfCourseName.setPreferredSize(new Dimension(250, 30));
        jtfCourseName.setBorder(BorderFactory.createLineBorder(BorderInput));
        jpnInfor.add(jlbCourseName);
        jpnInfor.add(jtfCourseName);
        jlbCourseName.setFont(new Font("Arial", Font.BOLD, 15));
        jtfCourseName.setFont(new Font("Arial", Font.BOLD, 15));

        JLabel jlbCourseDuration = new JLabel("Thời lượng khóa:");
        jtfCourseDuration = new JTextField();
        jlbCourseDuration.setBorder(new EmptyBorder(40, 0, 40, 0));
        jtfCourseDuration.setPreferredSize(new Dimension(250, 30));
        jtfCourseDuration.setBorder(BorderFactory.createLineBorder(BorderInput));
        jpnInfor.add(jlbCourseDuration);
        jpnInfor.add(jtfCourseDuration);
        jlbCourseDuration.setFont(new Font("Arial", Font.BOLD, 15));
        jtfCourseDuration.setFont(new Font("Arial", Font.BOLD, 15));

        JLabel jlbCourseFee = new JLabel("Giá tiền:");
        jtfCourseFee = new JTextField();
        jlbCourseFee.setBorder(new EmptyBorder(0, 10, 10, 10));
        jtfCourseFee.setPreferredSize(new Dimension(250, 30));
        jtfCourseFee.setBorder(BorderFactory.createLineBorder(BorderInput));
        jpnInfor.add(jlbCourseFee);
        jpnInfor.add(jtfCourseFee);
        jlbCourseFee.setFont(new Font("Arial", Font.BOLD, 15));
        jtfCourseFee.setFont(new Font("Arial", Font.BOLD, 15));

        jlbDescribe = new JLabel("Mô tả:");
        jtrDescribe = new JTextArea();
        jtrDescribe.setBorder(new LineBorder(BorderInput, 1));
        jtrDescribe.setPreferredSize(new Dimension(250, 100));
        jpnInfor.add(jlbDescribe);
        jpnInfor.add(jtrDescribe);
        jlbDescribe.setFont(new Font("Arial", Font.BOLD, 15));
        jtrDescribe.setFont(new Font("Arial", Font.BOLD, 15));

        jpnRoot.add(jpnController, BorderLayout.NORTH);
        jpnRoot.add(jpnContent, BorderLayout.CENTER);

        this.setLayout(new BorderLayout());
        this.add(jpnRoot);
        this.setResizable(false);
        this.setVisible(true);
    }

}
