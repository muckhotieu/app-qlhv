package View;

import Controller.HomeController;
import static Controller.ModeColorController.ColorBgMenu;
import static Controller.ModeColorController.ColorBgTotal;
import static Controller.ModeColorController.ColorForeMenu;
import static Controller.ModeColorController.ColorForeToTal;
import Utils.RoundedJPanelUntil;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class HomeJPanel extends JPanel {

    private JPanel jpnDetail;
    private JLabel jlbNumST;
    private JLabel jlbNumC;

    public HomeJPanel() {
        this.init();
        HomeController controller = new HomeController(jlbNumC, jlbNumST, jpnDetail);
        controller.renderData();
    }

    public final void init() {

        JPanel jpnContainer = new JPanel();
        jpnContainer.setBorder(new EmptyBorder(0, 20, 0, 20));
        jpnContainer.setLayout(new BorderLayout());

        RoundedJPanelUntil jpnTitle = new RoundedJPanelUntil(30, new Color(51, 0, 102));
        jpnTitle.setPreferredSize(new Dimension(getWidth(), 150));
//        jpnTitle.setLayout();
        jpnTitle.setBackground(ColorBgMenu);
        JLabel jlbWelcome = new JLabel("Welcome to Student Management App");
        jlbWelcome.setBorder(new EmptyBorder(20, 70, 0, 0));
        jlbWelcome.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 40));
        jlbWelcome.setForeground(ColorForeMenu);
        JLabel jlbSlogan = new JLabel("Exploding to knock down the challenge");
        jlbSlogan.setFont(new Font("Arial Rounded MT Bold", Font.PLAIN, 20));
        jlbSlogan.setForeground(ColorForeMenu);
        jpnTitle.add(jlbWelcome);
        jpnTitle.add(jlbSlogan);

        JPanel jpnStatistical = new JPanel();
        jpnStatistical.setLayout(new GridLayout(1, 3, 10, 0));
        jpnStatistical.setBorder(new EmptyBorder(15, 7, 0, 0));

        Font font = new Font("Arial", Font.PLAIN, 30);
        RoundedJPanelUntil jpnTotalStudent = new RoundedJPanelUntil(30, ColorBgMenu);
        jpnTotalStudent.setBackground(ColorBgTotal);
        jpnTotalStudent.setLayout(new BorderLayout());
        JLabel jlbTotalStudent = new JLabel("Total students ");
        jlbTotalStudent.setBorder(new EmptyBorder(10, 100, 0, 0));
        jlbTotalStudent.setForeground(ColorForeToTal);
        jlbTotalStudent.setFont(font);
        jpnTotalStudent.add(jlbTotalStudent, BorderLayout.NORTH);
        jlbNumST = new JLabel();
        jlbNumST.setBorder(new EmptyBorder(10, 160, 0, 0));
        jlbNumST.setForeground(ColorForeToTal);
        jlbNumST.setFont(font);
        jpnTotalStudent.add(jlbNumST, BorderLayout.CENTER);

        RoundedJPanelUntil jpnTotalCourse = new RoundedJPanelUntil(30, ColorBgMenu);
        jpnTotalCourse.setBackground(ColorBgTotal);
        jpnTotalCourse.setLayout(new BorderLayout());
        JLabel jlbTotalcourse = new JLabel("Total courses");
        jlbTotalcourse.setBorder(new EmptyBorder(10, 100, 0, 0));
        jlbTotalcourse.setForeground(ColorForeToTal);
        jlbTotalcourse.setFont(font);
        jpnTotalCourse.add(jlbTotalcourse, BorderLayout.NORTH);
        jlbNumC = new JLabel("30");
        jlbNumC.setBorder(new EmptyBorder(10, 160, 0, 0));
        jlbNumC.setForeground(ColorForeToTal);
        jlbNumC.setFont(font);
        jpnTotalCourse.add(jlbNumC, BorderLayout.CENTER);

        RoundedJPanelUntil jpnMail = new RoundedJPanelUntil(30, ColorBgMenu);
        jpnMail.setBackground(ColorBgTotal);
        jpnMail.setLayout(new BorderLayout());
        JLabel jlbMailBox = new JLabel("Mailbox");
        jlbMailBox.setBorder(new EmptyBorder(10, 130, 0, 0));
        jlbMailBox.setForeground(ColorForeToTal);
        jlbMailBox.setFont(font);
        jpnMail.add(jlbMailBox, BorderLayout.NORTH);
        JLabel jlbNumM = new JLabel("30");
        jlbNumM.setBorder(new EmptyBorder(10, 160, 0, 0));
        jlbNumM.setForeground(ColorForeToTal);
        jlbNumM.setFont(font);
        jpnMail.add(jlbNumM, BorderLayout.CENTER);

        jpnStatistical.add(jpnTotalStudent);
        jpnStatistical.add(jpnTotalCourse);
        jpnStatistical.add(jpnMail);

        jpnDetail = new JPanel();
        jpnDetail.setBorder(new EmptyBorder(20, 0, 0, 0));
        jpnDetail.setPreferredSize(new Dimension(getWidth(), 550));

        jpnContainer.add(jpnTitle, BorderLayout.NORTH);
        jpnContainer.add(jpnStatistical, BorderLayout.CENTER);
        jpnContainer.add(jpnDetail, BorderLayout.SOUTH);
        //chia layout
        this.setLayout(new BorderLayout());
        this.add(jpnContainer, BorderLayout.CENTER);

    }
}
