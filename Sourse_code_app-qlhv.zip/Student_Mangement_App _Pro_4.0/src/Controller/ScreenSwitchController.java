package Controller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.List;

import javax.swing.JLabel;
import javax.swing.JPanel;

import Bean.CategoryBean;
import static Controller.ModeColorController.ColorBgMenu;
import static Controller.ModeColorController.ColorBgMenuController;
import View.CourseJPanel;
import View.StudentRestorationJPanel;
import View.HomeJPanel;
import View.StudentJPanel;
import View.ClassJPanel;
import View.CourseRestorationJPanel;
import View.SettingJPanel;

public class ScreenSwitchController {

    private final JPanel jPanelRoot;
    public static String currentPage = "";
    List<CategoryBean> listItem = null;

    public ScreenSwitchController(JPanel jPanelRoot) {
        this.jPanelRoot = jPanelRoot;
    }

    public void setView(JPanel jPanelItem, JLabel jLabelItem) {
        currentPage = "Home";
        jPanelItem.setBackground(ColorBgMenuController);
        jLabelItem.setBackground(ColorBgMenuController);

        jPanelRoot.removeAll();
        jPanelRoot.setLayout(new BorderLayout());
        jPanelRoot.add(new HomeJPanel());
        jPanelRoot.validate();
        jPanelRoot.repaint();
    }

    public void setEvent(List<CategoryBean> listItem) {
        this.listItem = listItem;
        for (CategoryBean item : listItem) {
            item.getjLabel().addMouseListener(new LabelEvent(item.getKind(), item.getjPanel(), item.getjLabel()));
        }
    }

    class LabelEvent implements MouseListener {

        private JPanel node;
        private final String kind;
        private final JPanel jPanelItem;
        private final JLabel jLabelItem;

        public LabelEvent(String kind, JPanel jPanelItem, JLabel jLabelItem) {
            this.kind = kind;
            this.jPanelItem = jPanelItem;
            this.jLabelItem = jLabelItem;
        }

        @Override
        public void mouseClicked(MouseEvent e) {
            switch (kind) {
                case "Home" -> {
                    node = new HomeJPanel();
                }
                case "Student" -> {
                    node = new StudentJPanel();
                }
                case "Course" -> {
                    node = new CourseJPanel();
                }
                case "Class" -> {
                    node = new ClassJPanel();
                }
                case "StudentRestoration" -> {
                    node = new StudentRestorationJPanel();
                }
                case "CourseRestoration" -> {
                    node = new CourseRestorationJPanel();
                }
                case "Setting" -> {
                    node = new SettingJPanel();
                }
                default -> {
                }
            }
            jPanelRoot.removeAll();
            jPanelRoot.setLayout(new BorderLayout());
            jPanelRoot.add(node);
            jPanelRoot.validate();
            jPanelRoot.repaint();
            setChangeBackground(kind);
        }

        @Override
        public void mousePressed(MouseEvent e) {
//            currentPage = kind;
//            jPanelItem.setBackground(new Color(255, 255, 204));
//            jLabelItem.setBackground(new Color(255, 255, 204));
        }

        @Override
        public void mouseReleased(MouseEvent e) {
            // Nếu currentPage trùng với kind hiện tại thì không cần thay đổi màu nút
            if (currentPage.equalsIgnoreCase(kind)) {
                return;
            }
            jPanelItem.setBackground(ColorBgMenu);
            jLabelItem.setBackground(ColorBgMenu);
        }

        @Override
        public void mouseEntered(MouseEvent e) {
            if (!currentPage.equalsIgnoreCase(kind)) {
                jPanelItem.setBackground(ColorBgMenuController);
                jLabelItem.setBackground(ColorBgMenuController);
            }
        }

        @Override
        public void mouseExited(MouseEvent e) {
            if (!currentPage.equalsIgnoreCase(kind)) {
                jPanelItem.setBackground(ColorBgMenu);
                jLabelItem.setBackground(ColorBgMenu);
            }
        }
    }

    private void setChangeBackground(String kind) {
        for (CategoryBean item : listItem) {
            if (item.getKind().equalsIgnoreCase(kind)) {
                item.getjPanel().setBackground(ColorBgMenuController);
                item.getjLabel().setBackground(ColorBgMenuController);
            } else {
                item.getjPanel().setBackground(ColorBgMenu);
                item.getjLabel().setBackground(ColorBgMenu);
            }
        }
    }
}
