package Controller;

import View.FormLoginJPanel;
import java.awt.BorderLayout;
import java.awt.Dialog;
import javax.swing.JPanel;

public class AuthenticationManagerController {

    public static Dialog authenticationManagerDialog;
    public static JPanel jpnUserAuth;

    public AuthenticationManagerController(Dialog authenticationManagerDialog, JPanel jpnUserAuth) {
        AuthenticationManagerController.authenticationManagerDialog = authenticationManagerDialog;
        AuthenticationManagerController.jpnUserAuth = jpnUserAuth;
    }

    public void createUI() {
        if (jpnUserAuth != null) {
            FormLoginJPanel loginPanel = new FormLoginJPanel();
            jpnUserAuth.removeAll();
            jpnUserAuth.setLayout(new BorderLayout());
            jpnUserAuth.add(loginPanel, BorderLayout.CENTER);
            jpnUserAuth.validate();
            jpnUserAuth.repaint();
        }
    }
}
