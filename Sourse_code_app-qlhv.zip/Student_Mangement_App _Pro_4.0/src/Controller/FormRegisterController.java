package controller;

import static Controller.AuthenticationManagerController.jpnUserAuth;
import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import model.Account;
import Service.AccountService;
import Service.AccountServiceImpl;
import View.FormLoginJPanel;
import javax.swing.JPasswordField;

public class FormRegisterController {

    private final JButton btnSubmit;
    private final JButton btnReset;
    private final JButton btnLogin;
    private final JTextField jtfUserName;
    private final JPasswordField jpfPassword;
    private final JPasswordField jpfConfirmPassword;
    private final JLabel jlbMsg;

    private AccountService accountService = null;

    public FormRegisterController(JButton btnSubmit, JButton btnReset, JButton btnLogin, JTextField jtfUserName, 
            JPasswordField jtfPassword, JPasswordField jtfPasswordComfirm, JLabel jlbMsg, JPanel jpnFormRegister) {
        this.btnSubmit = btnSubmit;
        this.btnReset = btnReset;
        this.btnLogin = btnLogin;
        this.jtfUserName = jtfUserName;
        this.jpfPassword = jtfPassword;
        this.jpfConfirmPassword = jtfPasswordComfirm;
        this.jlbMsg = jlbMsg;
        accountService = new AccountServiceImpl();
    }

    public void setEvent() {
        btnSubmit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String password = new String(jpfPassword.getPassword());
                String comfirmPassword = new String(jpfConfirmPassword.getPassword());
                try {
                  
                    if (jtfUserName.getText().length() == 0
                            || password.length() == 0
                            || comfirmPassword.length() == 0) {
                        jlbMsg.setText("Please enter required data");
                    } else {
                        if (!jtfUserName.getText().matches("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$")){
                            jlbMsg.setText("Username must be email.");
                        }else if (!jtfUserName.getText().matches("^\\S+$")) {
                            jlbMsg.setText("Username must not contain any whitespace.");
                        } else if (accountService.isUsernameExist(jtfUserName.getText())) {
                            jlbMsg.setText("The account name already exists on the system");
                        } else if (!password.matches("^\\S{6,}$")) {
                            jlbMsg.setText("Password must be at least 6 characters long ");
                        } else if (!password.equals(comfirmPassword)) {
                            
                            jlbMsg.setText("Password re-enter mismatch");
                        } else {
                            Account account = new Account();
                            account.setUserName(jtfUserName.getText());
                            account.setPassword(password);
                            account.setStatus(true);
                            accountService.register(account);
                            jlbMsg.setText("Successful registration");

                        }
                    }
                } catch (Exception ex) {
                    System.out.println(ex.toString());
                    jlbMsg.setText("Connection error");
                }
            }

        });
        btnReset.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jtfUserName.setText("");
                jpfPassword.setText("");
                jpfConfirmPassword.setText("");
            }
        });
        btnLogin.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                    JPanel node = new FormLoginJPanel();
                    jpnUserAuth.removeAll();
                    jpnUserAuth.setLayout(new BorderLayout());
                    jpnUserAuth.add(node);
                    jpnUserAuth.validate();
                    jpnUserAuth.repaint();
                }
            }
        );
    }
}
