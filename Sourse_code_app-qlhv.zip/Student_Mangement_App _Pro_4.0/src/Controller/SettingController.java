package Controller;

import static Controller.ModeColorController.changeModeColor;
import View.AuthenticationManagerJDialog;
import static controller.FormLoginController.mainJFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;

/**
 *
 * @author MUCKHOTAU
 */
public class SettingController {

    private final JButton btnLogout;
    private final JRadioButton JrDark;
    private final JRadioButton JrBright;
    private final ModeColorController colorController;

    public SettingController(JRadioButton JrBright, JRadioButton JrDark, JButton btnLogout) {
        this.btnLogout = btnLogout;
        this.JrBright = JrBright;
        this.JrDark = JrDark;
        colorController = new ModeColorController();
    }

    public void setEvent() {
        // Đăng ký sự kiện ActionListener cho các JRadioButton
        JrBright.addActionListener((ActionEvent e) -> {
            ModeColorController.ModeColor = true;
            changeModeColor();
            ScreenSwitchController.currentPage = "Setting";
            mainJFrame.resetFrame();
            mainJFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
            // Đặt JFrame không cho phép phóng to/thu nhỏ cửa sổ

        });

        JrDark.addActionListener((ActionEvent e) -> {
            ModeColorController.ModeColor = false;
            changeModeColor();
            ScreenSwitchController.currentPage = "Setting";
            mainJFrame.resetFrame();
            mainJFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
            // Đặt JFrame không cho phép phóng to/thu nhỏ cửa sổ
        });
        btnLogout.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int dialogComfirmHardDelete = JOptionPane.showConfirmDialog(null, "Note: You want to sign out?", "Confirmation", JOptionPane.YES_NO_OPTION);
                if (dialogComfirmHardDelete == JOptionPane.YES_OPTION) {
                    mainJFrame.dispose();
                    AuthenticationManagerJDialog authenticationManagerJDialog = new AuthenticationManagerJDialog();
                }
            }
        }
        );
    }
}
