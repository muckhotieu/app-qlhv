package Controller;

import Bean.EnrollmentData;
import static Controller.ModeColorController.ColorBgExport;
import static Controller.ModeColorController.ColorBgExportController;
import Dao.EnrollmentDAO;
import Dao.EnrollmentDAOImpl;
import Model.Course;
import Model.Student;
import Service.CourseService;
import Service.CourseServiceImpl;
import Service.EnrollmentService;
import Service.EnrollmentServiceImpl;
import View.CourseJPanel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import static View.CourseRestorationJPanel.courseRestorationPageController;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.SwingWorker;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CourseController {

    private final JButton btnSubmit;
    private final JButton btnDelete;
    private final JButton btnExport;

    private final JTextField jtfCourseCode;
    private final JTextField jtfCourseName;
    private final JTextArea jtaDesc;
    private final JTextField jtfCourseDuration;
    private final JTextField jtfCourseFee;
    private final JLabel jlbMsg;

    private CourseService courseService = null;
    private EnrollmentService enrollmentService;

    private final JFrame courseJFrame;
    private Course course;

    public CourseController(JButton btnSubmit, JButton btnExport, JButton btnDelete, JTextField jtfCourseCode, JTextField jtfCourseName,
            JTextArea jtaDes, JTextField jtfCourseDuration, JTextField jtfCourseFee, JLabel jlbMsg, JFrame courseJFrame) {
        this.btnSubmit = btnSubmit;
        this.btnDelete = btnDelete;
        this.btnExport = btnExport;
        this.jtfCourseCode = jtfCourseCode;
        this.jtfCourseName = jtfCourseName;
        this.jtaDesc = jtaDes;
        this.jtfCourseDuration = jtfCourseDuration;
        this.jtfCourseFee = jtfCourseFee;
        this.jlbMsg = jlbMsg;
        this.courseJFrame = courseJFrame;

        this.courseService = new CourseServiceImpl();
        enrollmentService = new EnrollmentServiceImpl();
    }

    public void setView(Course course) {

        if (course == null) {
            return;
        }
        this.course = course;
        jtfCourseCode.setText(course.getCourseCode() != 0 ? Integer.toString(course.getCourseCode()) : "");
        jtfCourseName.setText(course.getCourseName() != null ? course.getCourseName() : "");
        jtaDesc.setText(course.getCourseDes() != null ? course.getCourseDes() : "");
        jtfCourseDuration.setText(course.getCourseDuration() != 0 ? Integer.toString(course.getCourseDuration()) : "");
        jtfCourseFee.setText(course.getCourseFee() != 0 ? Integer.toString(course.getCourseFee()) : "");
    }

    public void setEvent() {
        btnSubmit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // kiểm tra mã khóa học không được rỗng và phải là số
                if (jtfCourseName.getText().trim().length() == 0
                        || jtfCourseDuration.getText().isEmpty()) {
                    jlbMsg.setText("Dữ liệu không được để trống.");
                } else if (Integer.parseInt(jtfCourseDuration.getText()) <= 0) {
                    jlbMsg.setText("Thời lượng khóa học phải lớn hơn 0.");
                } else {
                    course.setCourseName(jtfCourseName.getText().trim());
                    course.setCourseDes(jtaDesc.getText());
                    course.setCourseDuration(Integer.parseInt(jtfCourseDuration.getText()));
                    course.setCourseFee(Integer.parseInt(jtfCourseFee.getText()));
                    course.setStatus(true);
                    if (showDialog()) {
                        int lastId = courseService.createOrUpdate(course);
                        if (lastId != 0) {
                            CourseJPanel.coursePageController.renderData(false);
                            CourseJPanel.coursePageController.setEven();

                            jlbMsg.setText("Cập nhật dữ liệu thành công!");
                            courseJFrame.dispose();
                        } else {
                            jlbMsg.setText("Có lỗi xảy ra, vui lòng thử lại!");
                        }
                    }
                }
            }

            private boolean showDialog() {
                int dialogResult = JOptionPane.showConfirmDialog(null,
                        "Muốn cập nhật dữ liệu ?", "Announcement", JOptionPane.YES_NO_OPTION);
                return dialogResult == JOptionPane.YES_OPTION;
            }

            public java.sql.Date convertDateToDateSql(Date d) {
                return new java.sql.Date(d.getTime());
            }
        });
        //XUẤT EXCEL
        btnExport.addMouseListener(new MouseAdapter() {
            public static FileOutputStream fis;

            @Override
            public void mouseClicked(MouseEvent e) {
                List<Student> listItem = enrollmentService.getListStudentInCourse(course);
                if (listItem.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "course empty!", "Notification", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JButton btn = (JButton) e.getSource();
                    btn.setBackground(ColorBgExportController);
                    //tạo 1 workbook mới của file excel
                    XSSFWorkbook workbook = new XSSFWorkbook();
                    XSSFSheet sheet = workbook.createSheet("Học viên");

                    // Tạo dòng tiêu đề
                    XSSFRow headerRow = sheet.createRow(0);

                    // Tạo các ô trong dòng tiêu đề
                    String[] columns = {"STT", "Mã sv", "Họ tên", "Ngày sinh", "Giới tính", "SĐT", "Gmail"};
                    for (int i = 0; i < columns.length; i++) {
                        Cell headerCell = headerRow.createCell(i, CellType.STRING);
                        headerCell.setCellValue(columns[i]);

                        CellStyle headerCellStyle = workbook.createCellStyle();
                        headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
                        headerCell.setCellStyle(headerCellStyle);
                        sheet.autoSizeColumn(i);
                    }

                    XSSFRow row = null;
                    Cell cell = null;

                    int s = listItem.size();
                    for (int i = 0; i < s; i++) {
                        Student student = listItem.get(i);

                        row = sheet.createRow(i + 1);

                        cell = row.createCell(0, CellType.NUMERIC);
                        cell.setCellValue(i + 1);

                        cell = row.createCell(1, CellType.NUMERIC);
                        cell.setCellValue(student.getStudentCode());

                        cell = row.createCell(2, CellType.STRING);
                        cell.setCellValue(student.getFullName());

                        cell = row.createCell(3, CellType.STRING);
                        cell.setCellValue(student.getDateOfBirth().toString());

                        cell = row.createCell(4, CellType.STRING);
                        cell.setCellValue(student.isSex() ? "Nam" : "Nữ");

                        cell = row.createCell(5, CellType.STRING);
                        cell.setCellValue(student.getPhoneNumber());

                        cell = row.createCell(6, CellType.STRING);
                        cell.setCellValue(student.getGmail());

                        for (int j = 0; j < columns.length; j++) {
                            CellStyle cellStyle = workbook.createCellStyle();
                            cellStyle.setAlignment(HorizontalAlignment.CENTER);
                            row.getCell(j).setCellStyle(cellStyle);
                            sheet.autoSizeColumn(j);
                        }
                    }
                    JFileChooser fileChooser = new JFileChooser();

                    // Thiết lập chế độ chỉ chọn đường dẫn để lưu file
                    fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

                    // Hiển thị hộp thoại chọn đường dẫn lưu file
                    int result = fileChooser.showSaveDialog(null);
                    File fileToSave = null;
                    // Kiểm tra người dùng đã chọn OK hay Cancel
                    if (result == JFileChooser.APPROVE_OPTION) {
                        // Lấy đường dẫn đã chọn
                        File selectedFile = fileChooser.getSelectedFile();
                        String filePath = selectedFile.getAbsolutePath();
                        // Tạo tên file mới cho file Excel
                        String excelFileName = "detail_course" + ".xlsx";
                        // Tạo đối tượng File để lưu file với tên mới
                        fileToSave = new File(filePath + "/" + excelFileName);
                        // Tạo đối tượng File để lưu file
//                        fileToSave = new File(filePath + "/student.xlsx");

                        // Tiến hành lưu file
                        // Ghi dữ liệu vào file và đóng file sau khi hoàn thành
                        // FileOutputStream fis = null;
                        try {
                            fis = new FileOutputStream(fileToSave);
                            SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
                                @Override
                                protected Void doInBackground() throws Exception {
                                    btnExport.setEnabled(false);
                                    workbook.write(fis);
                                    return null;
                                }

                                ;
                                @Override
                                protected void done() {
                                    try {
                                        JOptionPane.showMessageDialog(null, "File exported successfully!", "Notification", JOptionPane.INFORMATION_MESSAGE);
                                        btnExport.setEnabled(true);
                                        fileChooser.setSelectedFile(null);
                                        Thread.currentThread().setName("WorkerThreadExcel");
                                        // Không cần đóng luồng SwingWorker, nó sẽ tự động hoàn thành và kích hoạt done()
                                    } catch (Exception ex) {
                                    } finally {
                                        try {
                                            cancel(false);
                                            fis.close(); // Đóng luồng FileOutputStream
                                        } catch (IOException ex) {
                                        }
                                    }
                                }
                            };
                            worker.execute(); // Thực thi SwingWorker
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    } else if (result == JFileChooser.CANCEL_OPTION) {
                        return; // Thoát hàm nếu hủy chọn đường dẫn lưu file
                    }
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                JButton btn = (JButton) e.getSource();
                btn.setBackground(ColorBgExport);
            }
        });
        btnDelete.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int dialogResult = JOptionPane.showConfirmDialog(null,
                        "Có chắc là muốn xóa ko?", "Confirmation", JOptionPane.YES_NO_OPTION);
                if (dialogResult == JOptionPane.YES_OPTION) {
                    int res = courseService.softDelete(course);
                    if (res == 0) {
                        jlbMsg.setText("Lỗi , vui lòng thử lại!");
                    } else {
                        CourseJPanel.coursePageController.renderData(false);
                        courseRestorationPageController.setEven();
                        jlbMsg.setText("Xóa thành công!");
                        courseJFrame.setVisible(false);
                        courseJFrame.dispose();
                    }
                }
            }
        });
    }
}
