/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Service.CourseService;
import Service.CourseServiceImpl;
import Service.EnrollmentService;
import Service.EnrollmentServiceImpl;
import Utils.LineChartEnrollmentUntil;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class HomeController {

    private final EnrollmentService enrollmentService;
    private final CourseService courseService;
    private JLabel jlbTotalCourse;
    private JLabel jlbTotalStudent;
    private JPanel jpnLineChart;

    public HomeController(JLabel jlbTotalCourse, JLabel jlbTotalStudent, JPanel jpnLineChart) {
        this.jlbTotalCourse = jlbTotalCourse;
        this.jlbTotalStudent = jlbTotalStudent;
        this.jpnLineChart = jpnLineChart;
        this.enrollmentService = new EnrollmentServiceImpl();
        this.courseService = new CourseServiceImpl();
    }

    public void renderData() {
        int totalCourse = courseService.getTotalCourse();
        String totalCourseString = Integer.toString(totalCourse);
        jlbTotalCourse.setText(totalCourseString);
        int totalStudent = enrollmentService.getTotalStudent();
        String totalStudentString = Integer.toString(totalStudent);
        jlbTotalStudent.setText(totalStudentString);
        LineChartEnrollmentUntil lineChart = new LineChartEnrollmentUntil();
        lineChart.addLineChart(jpnLineChart);
               
    }

}
