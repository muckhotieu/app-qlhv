package Controller;

import java.awt.Color;

/**
 *
 * @author DELL
 */
public class ModeColorController {

    public static boolean ModeColor = true;
    // Declare and initialize color variables
    public static Color ColorBgMenu = new Color(51, 0, 102);
    public static Color ColorBgMenuController = new Color(76, 0, 153);
    public static Color ColorForeMenu = new Color(255, 255, 255);
    public static Color ColorBgTotal = new Color(255, 255, 255);
    public static Color ColorForeToTal = new Color(0, 0, 0);
    public static Color ColorBgAdd = new Color(102, 102, 0);
    public static Color ColorBgAddController = new Color(153, 153, 0);
    public static Color ColorForeAE = new Color(255, 255, 255);
    public static Color ColorBgExport = new Color(51, 102, 0);
    public static Color ColorBgExportController = new Color(76, 153, 0);
    public static Color ColorBgSubmit = new Color(0, 153, 76);
    public static Color ColorBgSubmitController = new Color(0, 204, 102);
    public static Color ColorBgDelete = new Color(153, 0, 76);
    public static Color ColorBgDeleteController = new Color(153, 0, 76);
    public static Color ColorForeSD = new Color(255, 255, 255);
    public static Color BorderInput = new Color(153, 204, 255);
    public static Color ColorBg = new Color (255, 255, 255);
    public static Color ColorText = new Color(0, 0, 0) ;
    public static Color ColorForeHelp =  new Color(255, 51, 51);

    // Phương thức để thay đổi chế độ màu
    public static void changeModeColor() {
        //nav
        ColorBgMenu = (ModeColor ? new Color(51, 0, 102) : new Color(204, 153, 255));
        ColorBgMenuController = (ModeColor ? new Color(76, 0, 153) : new Color(229, 204, 255));
        ColorForeMenu = (ModeColor ? new Color(255, 255, 255) : new Color(102, 51, 0));
        //Home
        ColorBgTotal = (ModeColor ? new Color(255, 255, 255) : new Color(51, 0, 102));
        ColorForeToTal = (ModeColor ? new Color(0, 0, 0) : new Color(255, 255, 255));
        //Student&course
        ColorBgAdd = (ModeColor ? new Color(102, 102, 0) : new Color(153, 255, 204));
        ColorBgAddController = (ModeColor ? new Color(153, 153, 0) : new Color(204, 255, 229));
        ColorForeAE = (ModeColor ? new Color(255, 255, 255) : new Color(102, 102, 0));
        ColorBgExport = (ModeColor ? new Color(51, 102, 0) : new Color(255, 204, 153));
        ColorBgExportController = (ModeColor ? new Color(76, 153, 0) : new Color(255, 229, 204));
        ColorBgSubmit = (ModeColor ? new Color(0, 153, 76) : new Color(153, 255, 153));
        ColorBgSubmitController = (ModeColor ? new Color(0, 204, 102) : new Color(204, 255, 204));
        ColorBgDelete = (ModeColor ? new Color(153, 0, 76) : new Color(255, 153, 204));
        ColorBgDeleteController = (ModeColor ? new Color(153, 0, 76) : new Color(255, 204, 229));
        ColorForeSD = (ModeColor ? new Color(255, 255, 255) : new Color(102, 102, 0));
        BorderInput = (ModeColor ? new Color(153, 204, 255) : new Color(255, 204, 153));
        //setting 
        ColorBg = (ModeColor ? new Color(255, 255, 255) :new Color(255,229,204));
        ColorText = (ModeColor ? new Color(0, 0, 0) :new Color(76,0,153));
        ColorForeHelp = (ModeColor ? new Color(255, 51, 51) : new Color(255,0,127));
    }
}
