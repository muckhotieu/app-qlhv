package Controller;

import javax.swing.JButton;
import javax.swing.JTextField;

import Model.Student;
import Service.StudentService;
import Service.StudentServiceImpl;
import View.StudentJPanel;
import com.toedter.calendar.JDateChooser;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import static View.StudentRestorationJPanel.studentRestorationPageController;

public class StudentController {

    private final JButton btnSubmit;
    private final JButton btnDelete;
    private final JTextField jtfStudentCode;
    private final JTextField jtfFullName;
    private final JDateChooser jdcDateOfBirth;
    private final JRadioButton jrMale;
    private final JRadioButton jrFemale;
    private final JTextField jtfNumber;
    private final JTextArea jtaGmail;
    private final JLabel jlbMsg;

    private Student student;
    private final StudentService studentService;
    private final JFrame StudentJFrame;
    
    public StudentController(JFrame StudentJFrame, JButton btnSubmit, JButton btnDelete, JTextField jtfStudentCode, JTextField jtfFullName,
            JDateChooser jdcDateOfBirth, JRadioButton jrMale, JRadioButton jrFemale,
            JCheckBox jcbActive, JTextField jtfNumber, JTextArea jtaGmail, JLabel jlbMsg) {
        this.StudentJFrame = StudentJFrame;
        this.btnSubmit = btnSubmit;
        this.btnDelete = btnDelete;
        this.jtfStudentCode = jtfStudentCode;
        this.jtfFullName = jtfFullName;
        this.jdcDateOfBirth = jdcDateOfBirth;
        this.jrMale = jrMale;
        this.jrFemale = jrFemale;
        this.jtfNumber = jtfNumber;
        this.jtaGmail = jtaGmail;
        this.jlbMsg = jlbMsg;

        this.studentService = new StudentServiceImpl();
    }

    public void setView(Student student) {
        if (student == null) {
            return;
        }
        this.student = student;
        jtfStudentCode.setText(student.getStudentCode() != 0 ? Integer.toString(student.getStudentCode()) : "");
        jtfFullName.setText(student.getFullName() != null ? student.getFullName() : "");
        jdcDateOfBirth.setDate(student.getDateOfBirth());
        jrMale.setSelected(student.isSex());
        jrFemale.setSelected(!student.isSex());
        jtfNumber.setText(student.getPhoneNumber() != null ? student.getPhoneNumber() : "");
        jtaGmail.setText(student.getGmail() != null ? student.getGmail() : "");
    }

    public void setEvent() {
        btnSubmit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                // kiểm tra mã khóa học không được rỗng và phải là số
                if (jtfFullName.getText().trim().length() == 0
                        || jtaGmail.getText().trim().length() == 0
                        || jdcDateOfBirth.getDate() == null) {
                    jlbMsg.setText("Dữ liệu không được để trống.");
                } else if (!isValidEmail(jtaGmail.getText().trim())) {
                    jlbMsg.setText("định dạng không email hợp lệ");
                } else {
                    student.setFullName(jtfFullName.getText().trim());
                    student.setDateOfBirth(convertDateToDateSql(jdcDateOfBirth.getDate()));
                    student.setPhoneNumber(jtfNumber.getText());
                    student.setGmail(jtaGmail.getText());
                    student.setSex(jrMale.isSelected());
                    student.setStatus(true);
                    if (showDialog()) {
                        int lastId = studentService.createOrUpdate(student);
                        if (lastId != 0) {
                            StudentJPanel.pageStudentController.renderData(false);
                            StudentJPanel.pageStudentController.setEven();
                            jlbMsg.setText("Lưu dữ liệu thành công!");
                            StudentJFrame.dispose();
                        } else {
                            jlbMsg.setText("Có lỗi xảy ra, vui lòng thử lại!");
                        }
                    }
                }
            }

            private boolean isValidEmail(String email) {
                // Biểu thức chính quy kiểm tra định dạng email
                String emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
                Pattern pattern = Pattern.compile(emailPattern);
                Matcher matcher = pattern.matcher(email);
                return matcher.matches();
            }

            private boolean showDialog() {
                int dialogResult = JOptionPane.showConfirmDialog(null,
                        "Do you want to update your data ?", "Announcement", JOptionPane.YES_NO_OPTION);
                return dialogResult == JOptionPane.YES_OPTION;
            }

            public java.sql.Date convertDateToDateSql(Date d) {
                return new java.sql.Date(d.getTime());
            }
        });
        btnDelete.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int dialogResult = JOptionPane.showConfirmDialog(null,
                        "Are you sure you want to delete this student?", "Confirmation", JOptionPane.YES_NO_OPTION);
                if (dialogResult == JOptionPane.YES_OPTION) {
                    int res = studentService.softDelete(student);
                    if (res == 0) {
                        jlbMsg.setText("Error: student cannot be deleted!");
                    } else {
                        StudentJPanel.pageStudentController.renderData(false);
                        studentRestorationPageController.setEven();
                        jlbMsg.setText("Student deleted successfully!");
                        StudentJFrame.setVisible(false);
                        StudentJFrame.dispose();
                    }
                }
            }
        });
    }
    
    
}
