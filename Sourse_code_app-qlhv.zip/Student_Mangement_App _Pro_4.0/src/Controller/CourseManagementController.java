package controller;

import static Controller.ModeColorController.ColorBgExport;
import static Controller.ModeColorController.ColorBgExportController;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import Model.Course;
import Service.CourseService;
import Service.CourseServiceImpl;
import Utils.TableModelUntil;
import View.CourseJFrame;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import static View.CourseRestorationJPanel.courseRestorationPageController;
import javax.swing.JFileChooser;
import javax.swing.SwingWorker;

/**
 *
 * @author MUCKHOTAU
 */
public class CourseManagementController {

    public final JPanel jpnView;
    private final JButton btnAdd;
    private final JButton btnExport;
    private final JTextField jtfSearch;

    private final String[] listColumn = {"Mã khóa học", "Tên khóa", "Mô tả", "Thời lượng(_h)", "Giá tiền(_$)", "Ngày đăng"};
    private TableRowSorter<TableModel> rowSorter = null;
    private final CourseService courseService;
    private DefaultTableModel model;
    private JTable tableCourse;
    private boolean isDeleted;

    public CourseManagementController(JPanel jpnView, JButton btnAdd, JTextField jtfSearch, JButton btnExport) {
        this.jpnView = jpnView;
        this.btnAdd = btnAdd;
        this.jtfSearch = jtfSearch;
        this.btnExport = btnExport;
        courseService = new CourseServiceImpl();
    }

    public void renderData(boolean isDeleted) {
        this.isDeleted = isDeleted;
        List<Course> listItem;
        listItem = courseService.getList(isDeleted);
        if (listItem == null) {
            JOptionPane.showMessageDialog(null, "Không có dữ liệu để hiển thị.", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        } else {
            model = new TableModelUntil().setTableCourse(listItem, listColumn);
            tableCourse = new JTable(model);

            // căn giữa text
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment(JLabel.CENTER);
            tableCourse.setDefaultRenderer(Object.class, centerRenderer);
//             Căn giữa dữ liệu trong cột 4 ?????????
            tableCourse.getColumnModel().getColumn(4).setCellRenderer(centerRenderer);
            // Set border color
            tableCourse.setBackground(Color.WHITE);
            tableCourse.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
            tableCourse.getTableHeader().setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
            // Set font
            tableCourse.setFont(new Font("Arial", Font.PLAIN, 16));
            tableCourse.getTableHeader().setFont(new Font("Arial", Font.BOLD, 20));

            // Set chiều rộng và dài
            tableCourse.getTableHeader().setPreferredSize(new Dimension(100, 50));
            tableCourse.setRowHeight(50);

            JScrollPane scrollPane = new JScrollPane();

            // Thêm thanh cuộn
            scrollPane.getViewport().add(tableCourse);

            // chia cot theo ti %
            int[] columnWidths = {12, 25, 23, 15, 13, 12};
            int tableWidth = 1300;
            for (int i = 0; i < tableCourse.getColumnCount(); i++) {
                TableColumn column = tableCourse.getColumnModel().getColumn(i);
                int width = Math.round(tableWidth * columnWidths[i] / 100f);
                column.setPreferredWidth(width);
            }
            // set kích thước thanh cuộn và border
            scrollPane.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            scrollPane.setPreferredSize(new Dimension(1300, 400));
            jpnView.removeAll();
            jpnView.setLayout(new BorderLayout());
            jpnView.add(scrollPane);

            // load lại view
            jpnView.validate();
            jpnView.repaint();
        }
    }

    private int convertToMinute(String durationStr) {
        int minutes = 0;
        if (durationStr.endsWith("m")) {
            minutes = Integer.parseInt(durationStr.substring(0, durationStr.length() - 1));
        } else if (durationStr.endsWith("h")) {
            minutes = Integer.parseInt(durationStr.substring(0, durationStr.length() - 1)) * 60;
        } else if (durationStr.endsWith("d")) {
            minutes = Integer.parseInt(durationStr.substring(0, durationStr.length() - 1)) * 1440;
        }
        return minutes;
    }

    private Course createCourseFromTableData(DefaultTableModel model, int rowIndex) throws ParseException {
        Course course = new Course();
        // Kiểm tra giá trị trước khi lấy
        Object courseCodeObj = model.getValueAt(rowIndex, 0);
        if (courseCodeObj != null) {
            int courseCode = Integer.parseInt(courseCodeObj.toString());
            course.setCourseCode(courseCode);
        } else {
            course.setCourseCode(0);
        }
        Object courseNameObj = model.getValueAt(rowIndex, 1);
        if (courseNameObj != null) {
            String courseName = courseNameObj.toString();
            course.setCourseName(courseName);
        } else {
            course.setCourseName("");
        }
        Object courseDesObj = model.getValueAt(rowIndex, 2);
        if (courseDesObj != null) {
            String courseDes = courseDesObj.toString();
            course.setCourseDes(courseDes);
        } else {
            course.setCourseDes("");
        }
//                      Phân giải ngược chuỗi về phút
        Object courseDurationObj = model.getValueAt(rowIndex, 3);
        String durationStr = courseDurationObj.toString();
        int minutes;
        String[] parts = durationStr.split(" ");
        minutes = switch (parts.length) {
            case 2 ->
                convertToMinute(parts[0]) + convertToMinute(parts[1]);
            case 3 ->
                convertToMinute(parts[0]) + convertToMinute(parts[1]) + convertToMinute(parts[2]);
            default ->
                convertToMinute(durationStr);
        };

        if (courseDurationObj != null) {
            course.setCourseDuration(minutes);
        } else {
            course.setCourseDuration(0);
        }

        Object courseFeeObj = model.getValueAt(rowIndex, 4);
        if (courseFeeObj != null) {
            int courseFee = Integer.parseInt(courseCodeObj.toString());
            course.setCourseFee(courseFee);
        } else {
            course.setCourseFee(0);
        }
        return course;
    }

    public void setEven() {
        rowSorter = new TableRowSorter<>(tableCourse.getModel());
        tableCourse.setRowSorter(rowSorter);
        jtfSearch.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                String text = jtfSearch.getText();
                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                String text = jtfSearch.getText();
                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
            }
        }
        );
        tableCourse.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && tableCourse.getSelectedRow() != -1) {
                    try {
                        int selectedRowIndex = tableCourse.getSelectedRow();
                        selectedRowIndex = tableCourse.convertRowIndexToModel(selectedRowIndex);
                        Course course = createCourseFromTableData(model, selectedRowIndex);
                        if (isDeleted) {
                            Object[] options = {"Recover", "Hard Delete", "Cancel"};
                            int dialogAction = JOptionPane.showOptionDialog(null,
                                    "Do you want to recover or hard delete this course?",
                                    "Confirmation",
                                    JOptionPane.YES_NO_CANCEL_OPTION,
                                    JOptionPane.QUESTION_MESSAGE,
                                    null,
                                    options,
                                    options[2]);
                            switch (dialogAction) {
                                case JOptionPane.YES_OPTION -> {
                                    int dialogComfirmRestore = JOptionPane.showConfirmDialog(null, "Do you definitely want to restore?", "Confirmation", JOptionPane.YES_NO_OPTION);
                                    if (dialogComfirmRestore == JOptionPane.YES_OPTION) {
                                        int res = courseService.recoverSoftDeletedCourse(course);
                                        if (res == 1) {
                                            // recover is successful
                                            courseRestorationPageController.renderData(true);
                                            courseRestorationPageController.setEven();
                                            JOptionPane.showMessageDialog(null, "Restore successful", "Success", JOptionPane.INFORMATION_MESSAGE);
                                        } else {
                                            // recover is failed
                                            JOptionPane.showMessageDialog(null, "Restore failed", "Error", JOptionPane.ERROR_MESSAGE);
                                        }
                                    }
                                }
                                case JOptionPane.NO_OPTION -> {
                                    int dialogComfirmHardDelete = JOptionPane.showConfirmDialog(null, "Note: After deletion, it will not be recoverable?", "Confirmation", JOptionPane.YES_NO_OPTION);
                                    if (dialogComfirmHardDelete == JOptionPane.YES_OPTION) {
                                        int res = courseService.hardDelete(course);
                                        if (res == 1) {
                                            // Hard delete is successful
                                            courseRestorationPageController.renderData(true);
                                            courseRestorationPageController.setEven();
                                            JOptionPane.showMessageDialog(null, "Deletion successful", "Success", JOptionPane.INFORMATION_MESSAGE);
                                        } else {
                                            // Hard delete failed
                                            JOptionPane.showMessageDialog(null, "Deletion failed", "Error", JOptionPane.ERROR_MESSAGE);
                                        }
                                    }
                                }
                                default -> {
                                }
                            }

                        } else {
                            int dialogComfirm = JOptionPane.showConfirmDialog(null,
                                    "Are you sure you want to edit this course?", "Confirmation", JOptionPane.YES_NO_OPTION);
                            if (dialogComfirm == JOptionPane.YES_OPTION) {
                                CourseJFrame frame = new CourseJFrame(course);
                                frame.setLocationRelativeTo(null);
                                frame.setResizable(false);
                                frame.setTitle("Thông tin sinh viên");
                                frame.setVisible(true);
                            }
                        }
                    } catch (ParseException ex) {
                        Logger.getLogger(CourseManagementController.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
            }

        });
        if (isDeleted == false) {
            btnAdd.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    CourseJFrame frame = new CourseJFrame(new Course());
                    frame.setTitle("Information Course");
                    frame.setLocationRelativeTo(null);
                    frame.setResizable(true);
                    frame.setVisible(true);
                }
            });
        }
        btnExport.addMouseListener(new MouseAdapter() {

            public static FileOutputStream fis;

            @Override
            public void mouseClicked(MouseEvent e) {
                List<Course> listItem = courseService.getList(isDeleted);
                if (listItem.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "ds khoa hoc rong!", "Notification", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JButton btn = (JButton) e.getSource();
                    btn.setBackground(ColorBgExportController);

                    XSSFWorkbook workbook = new XSSFWorkbook();
                    XSSFSheet sheet = workbook.createSheet("Khóa học");

                    // Tạo dòng tiêu đề
                    XSSFRow headerRow = sheet.createRow(0);

                    // Tạo các ô trong dòng tiêu đề
                    String[] columns = {"Mã khóa học", "Tên khóa", "Mô tả", "Thời lượng(_h)", "Giá tiền(_$)", "Ngày đăng"};
                    for (int i = 0; i < columns.length; i++) {
                        Cell headerCell = headerRow.createCell(i, CellType.STRING);
                        headerCell.setCellValue(columns[i]);

                        CellStyle headerCellStyle = workbook.createCellStyle();
                        headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
                        headerCell.setCellStyle(headerCellStyle);
                        sheet.autoSizeColumn(i);
                    }

                    XSSFRow row = null;
                    Cell cell = null;

                    int s = listItem.size();
                    for (int i = 0; i < s; i++) {
                        Course course = listItem.get(i);
                        row = sheet.createRow(i + 1);

                        cell = row.createCell(0, CellType.NUMERIC);
                        cell.setCellValue(course.getCourseCode());

                        cell = row.createCell(1, CellType.STRING);
                        cell.setCellValue(course.getCourseName());

                        cell = row.createCell(2, CellType.STRING);
                        cell.setCellValue(course.getCourseDes());

                        cell = row.createCell(3, CellType.NUMERIC);
                        cell.setCellValue(course.getCourseDuration());

                        cell = row.createCell(4, CellType.NUMERIC);
                        cell.setCellValue(course.getCourseFee());

                        cell = row.createCell(5, CellType.STRING);
                        cell.setCellValue(course.getCourseCreatedDate().toString());

                        for (int j = 0; j < columns.length; j++) {
                            CellStyle cellStyle = workbook.createCellStyle();
                            cellStyle.setAlignment(HorizontalAlignment.CENTER);
                            row.getCell(j).setCellStyle(cellStyle);
                            sheet.autoSizeColumn(j);
                        }
                    }
                    JFileChooser fileChooser = new JFileChooser();
                    // Thiết lập chế độ chỉ chọn đường dẫn để lưu file
                    fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

                    // Hiển thị hộp thoại chọn đường dẫn lưu file
                    int result = fileChooser.showSaveDialog(null);
                    File fileToSave = null;
                    // Kiểm tra người dùng đã chọn OK hay Cancel
                    if (result == JFileChooser.APPROVE_OPTION) {
                        // Lấy đường dẫn đã chọn
                        File selectedFile = fileChooser.getSelectedFile();
                        String filePath = selectedFile.getAbsolutePath();

                        // Tạo đối tượng File để lưu file
                        fileToSave = new File(filePath + "/Course.xlsx");

                        // Tiến hành lưu file
                        // Ghi dữ liệu vào file và đóng file sau khi hoàn thành
                        try {
                            fis = new FileOutputStream(fileToSave);
                            SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
                                @Override
                                protected Void doInBackground() throws Exception {
                                    btnExport.setEnabled(false);
                                    workbook.write(fis);
                                    return null;
                                }

                                ;
                                @Override
                                protected void done() {
                                    try {
                                        JOptionPane.showMessageDialog(null, "File exported successfully!", "Notification", JOptionPane.INFORMATION_MESSAGE);
                                        btnExport.setEnabled(true);
                                        fileChooser.setSelectedFile(null);
                                        Thread.currentThread().setName("WorkerThreadExcel");
                                        // Không cần đóng luồng SwingWorker, nó sẽ tự động hoàn thành và kích hoạt done()
                                    } catch (Exception ex) {
                                    } finally {
                                        try {
                                            cancel(false);
                                            fis.close(); // Đóng luồng FileOutputStream
                                        } catch (IOException ex) {
                                        }
                                    }
                                }
                            };
                            worker.execute(); // Thực thi SwingWorker
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    } else if (result == JFileChooser.CANCEL_OPTION) {
                        return; // Thoát hàm nếu hủy chọn đường dẫn lưu file
                    }
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                JButton btn = (JButton) e.getSource();
                btn.setBackground(ColorBgExport);
            }
        }
        );
    }

}
