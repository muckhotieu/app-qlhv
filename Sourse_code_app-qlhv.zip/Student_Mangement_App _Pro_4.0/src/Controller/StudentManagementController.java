package Controller;

import static Controller.ModeColorController.ColorBgExport;
import static Controller.ModeColorController.ColorBgExportController;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.RowFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import Model.Student;
import Service.StudentService;
import Service.StudentServiceImpl;
import Utils.TableModelUntil;
import View.StudentJFrame;
import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableColumn;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import static View.StudentRestorationJPanel.studentRestorationPageController;
import controller.CourseManagementController;
import java.io.IOException;
import javax.swing.JFileChooser;
import javax.swing.SwingWorker;

public class StudentManagementController {

    private final JPanel jpnView;
    private final JButton btnAdd;
    private final JTextField jtfSearch;
    private final JButton btnExport;

    private StudentService studentService = null;
    private final String[] listColumn = {"Stt", "Mã sv", "Họ tên", "Ngày sinh", "Giới tính", "SDT", "Gmail"};
    private DefaultTableModel model;
    private TableRowSorter<TableModel> rowSorter = null;
    private JTable tableStudent;
    private boolean isDeleted;

    public StudentManagementController(JPanel jPanelView, JButton btnAdd, JTextField jTextFieldSearch, JButton btnExport) {
        this.jpnView = jPanelView;
        this.btnAdd = btnAdd;
        this.btnExport = btnExport;
        this.jtfSearch = jTextFieldSearch;
        this.studentService = new StudentServiceImpl();
    }

    public void renderData(boolean isDeleted) {
        this.isDeleted = isDeleted;
        List<Student> listItem = studentService.getList(isDeleted);
        if (listItem == null) {
            JOptionPane.showMessageDialog(null, "Không có dữ liệu để hiển thị.", "Thông báo", JOptionPane.INFORMATION_MESSAGE);
        } else {
            model = new TableModelUntil().setTableStudent(listItem, listColumn);
            tableStudent = new JTable(model);

            // căn giữa text
            DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
            centerRenderer.setHorizontalAlignment(JLabel.CENTER);
            tableStudent.setDefaultRenderer(Object.class, centerRenderer);
            //căn giưax cho cột 0 và 3
            tableStudent.getColumnModel().getColumn(0).setCellRenderer(centerRenderer);
            tableStudent.getColumnModel().getColumn(3).setCellRenderer(centerRenderer);
            // Set border color
            tableStudent.setBackground(Color.WHITE);
            tableStudent.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
            tableStudent.getTableHeader().setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
            // Set font
            tableStudent.setFont(
                    new Font("Times New Roman", Font.PLAIN, 16));
            tableStudent.getTableHeader()
                    .setFont(new Font("Times New Roman", Font.BOLD, 20));

            // Set font
            tableStudent.setFont(new Font("Arial", Font.PLAIN, 16));
            tableStudent.getTableHeader().setFont(new Font("Arial", Font.BOLD, 20));

            // Set chiều rộng và dài
            tableStudent.getTableHeader().setPreferredSize(new Dimension(100, 50));
            tableStudent.setRowHeight(50);

            JScrollPane scrollPane = new JScrollPane();

            // Thêm thanh cuộn
            scrollPane.getViewport().add(tableStudent);

            // Calculate the column widths based on the visible width of the tableStudent
            int[] columnWidths = {5, 10, 22, 15, 12, 18, 33};
            int tableWidth = 1300;
            for (int i = 0;
                    i < tableStudent.getColumnCount();
                    i++) {
                TableColumn column = tableStudent.getColumnModel().getColumn(i);
                int width = Math.round(tableWidth * columnWidths[i] / 100f);
                column.setPreferredWidth(width);
            }
            // set kích thước thanh cuộn và border

            scrollPane.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
            scrollPane.setPreferredSize(
                    new Dimension(1300, 400));
            jpnView.removeAll();

            jpnView.setLayout(new BorderLayout());
            jpnView.add(scrollPane);

            // load lại view
            jpnView.validate();
            jpnView.repaint();
        }
    }

    private Student createStudentFromTableData(DefaultTableModel model, int rowIndex) throws ParseException {
        Student student = new Student();
        Object studentCodeObj = model.getValueAt(rowIndex, 1);
        if (studentCodeObj != null) {
            int studentCode = Integer.parseInt(studentCodeObj.toString());
            student.setStudentCode(studentCode);
        } else {
            student.setStudentCode(0);
        }

        Object fullNameObj = model.getValueAt(rowIndex, 2);
        if (fullNameObj != null) {
            String fullName = fullNameObj.toString();
            student.setFullName(fullName);
        } else {
            student.setFullName("");
        }

        Object dateOfBirthObj = model.getValueAt(rowIndex, 3);
        if (dateOfBirthObj != null) {
            String dateString = dateOfBirthObj.toString();
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
            Date date = format.parse(dateString);
            java.sql.Date sqlDate = new java.sql.Date(date.getTime());
            student.setDateOfBirth(sqlDate);
        }

        Object sexObj = model.getValueAt(rowIndex, 4);
        if (sexObj != null) {
            String sexString = sexObj.toString();
            student.setSex(sexString.equalsIgnoreCase("Nam"));
        }

        Object phoneNumberObj = model.getValueAt(rowIndex, 5);
        if (phoneNumberObj != null) {
            String phoneNumber = phoneNumberObj.toString();
            student.setPhoneNumber(phoneNumber);
        } else {
            student.setPhoneNumber("");
        }

        Object addressObj = model.getValueAt(rowIndex, 6);
        if (addressObj != null) {
            String address = addressObj.toString();
            student.setGmail(address);
        } else {
            student.setGmail("");
        }

        student.setStatus(true);
        return student;
    }

    public void setEven() {
        rowSorter = new TableRowSorter<>(tableStudent.getModel());
        tableStudent.setRowSorter(rowSorter);
        // Add document listener to search text field
        jtfSearch.getDocument().addDocumentListener(new DocumentListener() {

            @Override
            public void removeUpdate(DocumentEvent e) {
                String text = jtfSearch.getText();
                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }

            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                String text = jtfSearch.getText();
                if (text.trim().length() == 0) {
                    rowSorter.setRowFilter(null);
                } else {
                    rowSorter.setRowFilter(RowFilter.regexFilter("(?i)" + text));
                }
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
            }
        });
        // Add mouse listener to tableStudent
        tableStudent.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2 && tableStudent.getSelectedRow() != -1) {
                    try {
                        int selectedRowIndex = tableStudent.getSelectedRow();
                        selectedRowIndex = tableStudent.convertRowIndexToModel(selectedRowIndex);
                        Student student = student = createStudentFromTableData(model, selectedRowIndex);
                        if (isDeleted) {
                            Object[] options = {"Recover", "Hard Delete", "Cancel"};
                            int dialogAction = JOptionPane.showOptionDialog(null,
                                    "Do you want to recover or hard delete this student?",
                                    "Confirmation",
                                    JOptionPane.YES_NO_CANCEL_OPTION,
                                    JOptionPane.QUESTION_MESSAGE,
                                    null,
                                    options,
                                    options[2]);
                            switch (dialogAction) {
                                case JOptionPane.YES_OPTION -> {
                                    int dialogConfirmRestore = JOptionPane.showConfirmDialog(null,
                                            "Do you definitely want to restore?", "Confirmation", JOptionPane.YES_NO_OPTION);
                                    if (dialogConfirmRestore == JOptionPane.YES_OPTION) {
                                        int res = studentService.recoverSoftDeletedStudent(student);
                                        if (res == 1) {
                                            // recover is successful
                                            studentRestorationPageController.renderData(true);
                                            studentRestorationPageController.setEven();
                                            JOptionPane.showMessageDialog(null, "Restore successful", "Success", JOptionPane.INFORMATION_MESSAGE);
                                        } else {
                                            // recover is failed
                                            JOptionPane.showMessageDialog(null, "Restore failed", "Error", JOptionPane.ERROR_MESSAGE);
                                        }
                                    }
                                }

                                case JOptionPane.NO_OPTION -> {
                                    int dialogConfirmHardDelete = JOptionPane.showConfirmDialog(null,
                                            "Note: After deletion, it will not be recoverable?", "Confirmation", JOptionPane.YES_NO_OPTION);
                                    if (dialogConfirmHardDelete == JOptionPane.YES_OPTION) {
                                        int res = studentService.hardDelete(student);
                                        if (res == 1) {
                                            // Hard delete is successful
                                            studentRestorationPageController.renderData(true);
                                            studentRestorationPageController.setEven();
                                            jpnView.removeAll();
                                            JOptionPane.showMessageDialog(null, "Deletion successful", "Success", JOptionPane.INFORMATION_MESSAGE);

                                        } else {
                                            // Hard delete failed
                                            JOptionPane.showMessageDialog(null, "Deletion failed", "Error", JOptionPane.ERROR_MESSAGE);
                                        }
                                    }
                                }
                                default -> {
                                }
                            }

                            // Do nothing if cancel button or close icon is clicked
                        } else {
                            int dialogComfirm = JOptionPane.showConfirmDialog(null,
                                    "Are you sure you want to edit this student?", "Confirmation", JOptionPane.YES_NO_OPTION);
                            if (dialogComfirm == JOptionPane.YES_OPTION) {
                                StudentJFrame frame = new StudentJFrame(student);
                                frame.setLocationRelativeTo(null);
                                frame.setResizable(false);
                                frame.setTitle("Thông tin sinh viên");
                                frame.setVisible(true);
                            }
                        }
                    } catch (ParseException ex) {
                        Logger.getLogger(StudentManagementController.class.getName()).log(Level.SEVERE, null, ex);
                    }

                }
            }
        }
        );
        if (isDeleted == false) {
            btnAdd.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    StudentJFrame frame = new StudentJFrame(new Student());
                    frame.setTitle("Information Student");
                    frame.setLocationRelativeTo(null);
                    frame.setResizable(true);
                    frame.setVisible(true);
                }
            });
        }

        //XUẤT EXCEL
        btnExport.addMouseListener(new MouseAdapter() {
            public static FileOutputStream fis;

            @Override
            public void mouseClicked(MouseEvent e) {
                List<Student> listItem = studentService.getList(isDeleted);
                if (listItem.isEmpty()) {
                    JOptionPane.showMessageDialog(null, "ds sinh vien rong!", "Notification", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JButton btn = (JButton) e.getSource();
                    btn.setBackground(ColorBgExportController);
                    //tạo 1 workbook mới của file excel
                    XSSFWorkbook workbook = new XSSFWorkbook();
                    XSSFSheet sheet = workbook.createSheet("Học viên");

                    // Tạo dòng tiêu đề
                    XSSFRow headerRow = sheet.createRow(0);

                    // Tạo các ô trong dòng tiêu đề
                    String[] columns = {"STT", "Mã sv", "Họ tên", "Ngày sinh", "Giới tính", "SĐT", "Gmail"};
                    for (int i = 0; i < columns.length; i++) {
                        Cell headerCell = headerRow.createCell(i, CellType.STRING);
                        headerCell.setCellValue(columns[i]);

                        CellStyle headerCellStyle = workbook.createCellStyle();
                        headerCellStyle.setAlignment(HorizontalAlignment.CENTER);
                        headerCell.setCellStyle(headerCellStyle);
                        sheet.autoSizeColumn(i);
                    }

                    XSSFRow row = null;
                    Cell cell = null;

                    int s = listItem.size();
                    for (int i = 0; i < s; i++) {
                        Student student = listItem.get(i);

                        row = sheet.createRow(i + 1);

                        cell = row.createCell(0, CellType.NUMERIC);
                        cell.setCellValue(i + 1);

                        cell = row.createCell(1, CellType.NUMERIC);
                        cell.setCellValue(student.getStudentCode());

                        cell = row.createCell(2, CellType.STRING);
                        cell.setCellValue(student.getFullName());

                        cell = row.createCell(3, CellType.STRING);
                        cell.setCellValue(student.getDateOfBirth().toString());

                        cell = row.createCell(4, CellType.STRING);
                        cell.setCellValue(student.isSex() ? "Nam" : "Nữ");

                        cell = row.createCell(5, CellType.STRING);
                        cell.setCellValue(student.getPhoneNumber());

                        cell = row.createCell(6, CellType.STRING);
                        cell.setCellValue(student.getGmail());

                        for (int j = 0; j < columns.length; j++) {
                            CellStyle cellStyle = workbook.createCellStyle();
                            cellStyle.setAlignment(HorizontalAlignment.CENTER);
                            row.getCell(j).setCellStyle(cellStyle);
                            sheet.autoSizeColumn(j);
                        }
                    }
                    JFileChooser fileChooser = new JFileChooser();

                    // Thiết lập chế độ chỉ chọn đường dẫn để lưu file
                    fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

                    // Hiển thị hộp thoại chọn đường dẫn lưu file
                    int result = fileChooser.showSaveDialog(null);
                    File fileToSave = null;
                    // Kiểm tra người dùng đã chọn OK hay Cancel
                    if (result == JFileChooser.APPROVE_OPTION) {
                        // Lấy đường dẫn đã chọn
                        File selectedFile = fileChooser.getSelectedFile();
                        String filePath = selectedFile.getAbsolutePath();
                        // Tạo tên file mới cho file Excel
                        String excelFileName = "student" + ".xlsx";
                        // Tạo đối tượng File để lưu file với tên mới
                        fileToSave = new File(filePath + "/" + excelFileName);
                        // Tạo đối tượng File để lưu file
//                        fileToSave = new File(filePath + "/student.xlsx");

                        // Tiến hành lưu file
                        // Ghi dữ liệu vào file và đóng file sau khi hoàn thành
                        // FileOutputStream fis = null;
                        try {
                            fis = new FileOutputStream(fileToSave);
                            SwingWorker<Void, Void> worker = new SwingWorker<Void, Void>() {
                                @Override
                                protected Void doInBackground() throws Exception {
                                    btnExport.setEnabled(false);
                                    workbook.write(fis);
                                    return null;
                                }

                                ;
                                @Override
                                protected void done() {
                                    try {
                                        JOptionPane.showMessageDialog(null, "File exported successfully!", "Notification", JOptionPane.INFORMATION_MESSAGE);
                                        btnExport.setEnabled(true);
                                        fileChooser.setSelectedFile(null);
                                        Thread.currentThread().setName("WorkerThreadExcel");
                                        // Không cần đóng luồng SwingWorker, nó sẽ tự động hoàn thành và kích hoạt done()
                                    } catch (Exception ex) {
                                    } finally {
                                        try {
                                            cancel(false);
                                            fis.close(); // Đóng luồng FileOutputStream
                                        } catch (IOException ex) {
                                        }
                                    }
                                }
                            };
                            worker.execute(); // Thực thi SwingWorker
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    } else if (result == JFileChooser.CANCEL_OPTION) {
                        return; // Thoát hàm nếu hủy chọn đường dẫn lưu file
                    }
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                JButton btn = (JButton) e.getSource();
                btn.setBackground(ColorBgExport);
            }
        });
    }

}
