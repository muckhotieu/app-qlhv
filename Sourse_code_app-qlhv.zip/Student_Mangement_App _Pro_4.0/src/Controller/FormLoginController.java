package controller;

import static Controller.AuthenticationManagerController.authenticationManagerDialog;
import static Controller.AuthenticationManagerController.jpnUserAuth;
import java.awt.BorderLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import model.Account;
import Service.AccountService;
import Service.AccountServiceImpl;
import View.FormRegisterJPanel;
import View.MainJFrame;
import javax.swing.JPasswordField;
public class FormLoginController {

    private final JButton btnSubmit;
    private final JButton btnReset;
    private final JButton btnSignUp;
    private final JTextField jtfUserName;
    private final JPasswordField jpfPassword;
    private final JLabel jlbMsg;
    private AccountService accountService = null;
    public static Account loggedInAccount;
    public static MainJFrame mainJFrame;
    public FormLoginController(JButton btnSubmit, JButton btnReset, JButton btnSignUp, JTextField jtfUserName, JPasswordField jtfPassword, JLabel jlbMsg) {
        this.btnSubmit = btnSubmit;
        this.btnReset = btnReset;
        this.btnSignUp = btnSignUp;
        this.jtfUserName = jtfUserName;
        this.jpfPassword = jtfPassword;
        this.jlbMsg = jlbMsg;
        accountService = new AccountServiceImpl();
    }

    public void setEvent() {
        btnSubmit.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String password = new String(jpfPassword.getPassword());
                try {
                    if (jtfUserName.getText().length() == 0 || password.length() == 0) {
                        jlbMsg.setText("Please enter required data");
                    } else {
                        loggedInAccount = accountService.login(jtfUserName.getText(), password);
                        if (loggedInAccount == null) {
                            jlbMsg.setText("Username and password are incorrect");
                        } else {
                            if (!loggedInAccount.isStatus()) {
                                jlbMsg.setText("Your account is temporarily locked");
                            } else {
                                authenticationManagerDialog.dispose();
                                mainJFrame = new MainJFrame();
                                mainJFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
                                mainJFrame.setVisible(true);
                            }
                        }
                    }
                } catch (Exception ex) {
                    System.out.println(ex.toString());
                    jlbMsg.setText("Connection error");
                }
            }
        });

        btnReset.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                jtfUserName.setText("");
                jpfPassword.setText("");
            }
        });

        btnSignUp.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                JPanel node = new FormRegisterJPanel();
                jpnUserAuth.removeAll();
                jpnUserAuth.setLayout(new BorderLayout());
                jpnUserAuth.add(node);
                jpnUserAuth.validate();
                jpnUserAuth.repaint();
            }
        });
    }

}
