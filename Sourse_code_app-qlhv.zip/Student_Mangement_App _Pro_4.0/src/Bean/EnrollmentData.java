/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Bean;

/**
 *
 * @author MUCKHOTAU
 */
public class EnrollmentData {

    private int enrollmentCount;
    private String enrollmentDate;

    public EnrollmentData(int enrollmentCount, String enrollmentDate) {
        this.enrollmentCount = enrollmentCount;
        this.enrollmentDate = enrollmentDate;
    }

    public EnrollmentData() {
    }

    public int getEnrollmentCount() {
        return enrollmentCount;
    }

    public void setEnrollmentCount(int enrollmentCount) {
        this.enrollmentCount = enrollmentCount;
    }

    public String getEnrollmentDate() {
        return enrollmentDate;
    }

    public void setEnrollmentDate(String enrollmentDate) {
        this.enrollmentDate = enrollmentDate;
    }
}
