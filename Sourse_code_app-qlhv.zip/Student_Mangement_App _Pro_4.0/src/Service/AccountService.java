package Service;

import model.Account;

/**
 *
 * @author MUCKHOTAU
 */
public interface AccountService {
    public Account login(String userName, String password);
    public boolean register(Account account);
    public boolean isUsernameExist(String username);
}
