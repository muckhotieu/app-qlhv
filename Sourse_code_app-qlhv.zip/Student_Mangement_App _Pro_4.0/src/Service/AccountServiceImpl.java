/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Dao.AccountDAO;
import Dao.AccountDAOImpl;
import model.Account;

/**
 *
 * @author MUCKHOTAU
 */
public class AccountServiceImpl implements AccountService {
    private AccountDAO accountDAO = null;
    public AccountServiceImpl() {
        accountDAO = new AccountDAOImpl();
    }

    @Override
    public Account login(String userName, String password) {
        return accountDAO.login(userName, password);
    }
    @Override
    public boolean register(Account account) {
        return accountDAO.register(account);
    }
    @Override
    public boolean isUsernameExist(String username) {
        return accountDAO.isUsernameExist(username);
    }
}
