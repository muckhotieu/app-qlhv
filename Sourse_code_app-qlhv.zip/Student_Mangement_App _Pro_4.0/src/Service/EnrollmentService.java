/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Bean.EnrollmentData;
import Model.Course;
import Model.Student;
import java.util.List;

/**
 *
 * @author MUCKHOTAU
 */
public interface EnrollmentService {
    public List<EnrollmentData> getEnrollmentList();
    public int getTotalStudent();
    public List<Student> getListStudentInCourse(Course course);
}
