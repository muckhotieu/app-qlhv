package Service;

import java.util.List;

import Dao.StudentDAO;
import Dao.StudentDaoImpl;
import Model.Student;

public class StudentServiceImpl implements StudentService {

    private StudentDAO studentDAO = null;

    public StudentServiceImpl() {
        studentDAO = new StudentDaoImpl();
    }

    @Override
    public List<Student> getList(boolean isDeleted) {
        return studentDAO.getList(isDeleted);
    }

    @Override
    public int createOrUpdate(Student student) {
        return studentDAO.createOrUpdate(student);
    }

    @Override
    public int softDelete(Student student) {
        return studentDAO.softDelete(student);
    }

    @Override
    public int hardDelete(Student student) {
        return studentDAO.hardDelete(student);
    }
    
    @Override
    public int recoverSoftDeletedStudent(Student student) { 
        return studentDAO.recoverSoftDeletedStudent(student);
    }

}
