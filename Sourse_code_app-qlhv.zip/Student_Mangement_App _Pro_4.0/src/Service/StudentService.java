package Service;

import java.util.List;

import Model.Student;

public interface StudentService {

    public List<Student> getList(boolean isDeleted);

    public int createOrUpdate(Student student);

    public int softDelete(Student student);

    public int hardDelete(Student student);
    
    public int recoverSoftDeletedStudent(Student student);
}
