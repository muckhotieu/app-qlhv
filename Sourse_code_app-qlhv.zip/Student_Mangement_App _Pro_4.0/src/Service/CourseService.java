/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Model.Course;
import Model.Student;
import java.util.List;

/**
 *
 * @author MUCKHOTAU
 */
public interface CourseService {

    public List<Course> getList(boolean isDeleted);

    public int createOrUpdate(Course course);

    public int softDelete(Course course);

    public int hardDelete(Course course);

    public int recoverSoftDeletedCourse(Course course);

    public int getTotalCourse();

}
