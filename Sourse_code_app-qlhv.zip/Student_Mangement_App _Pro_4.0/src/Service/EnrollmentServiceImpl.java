/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Bean.EnrollmentData;
import Dao.EnrollmentDAO;
import Dao.EnrollmentDAOImpl;
import Model.Course;
import Model.Student;
import java.util.List;

/**
 *
 * @author MUCKHOTAU
 */
public class EnrollmentServiceImpl implements EnrollmentService {

    private final EnrollmentDAO enrollmentDAO;

    public EnrollmentServiceImpl() {
        this.enrollmentDAO = new EnrollmentDAOImpl();
    }

    @Override
    public List<EnrollmentData> getEnrollmentList() {
        return enrollmentDAO.getEnrollmentList();
    }

    @Override
    public int getTotalStudent() {
        return enrollmentDAO.getTotalStudent();
    }

    @Override
    public List<Student> getListStudentInCourse(Course course) {
        return enrollmentDAO.getListStudentInCourse(course);
    }
}
