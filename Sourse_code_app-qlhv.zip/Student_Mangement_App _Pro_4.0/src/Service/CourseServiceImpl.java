/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Service;

import Dao.CourseDAO;
import Dao.CourseDAOImpl;
import Model.Course;
import Model.Student;
import java.util.List;

/**
 *
 * @author MUCKHOTAU
 */
public class CourseServiceImpl implements CourseService {

    private CourseDAO courseDAO = null;

    public CourseServiceImpl() {
        courseDAO = new CourseDAOImpl();
    }

    @Override
    public List<Course> getList(boolean isDeleted) {
        return courseDAO.getList(isDeleted);
    }

    @Override
    public int createOrUpdate(Course course) {
        return courseDAO.createOrUpdate(course);
    }

    @Override
    public int softDelete(Course course) {
        return courseDAO.softDelete(course);
    }

    @Override
    public int hardDelete(Course course) {
        return courseDAO.hardDelete(course);
    }

    @Override
    public int recoverSoftDeletedCourse(Course course) {
        return courseDAO.recoverSoftDeletedCourse(course);
    }

    @Override
    public int getTotalCourse() {
        return courseDAO.getTotalCourse();    
    }

}
